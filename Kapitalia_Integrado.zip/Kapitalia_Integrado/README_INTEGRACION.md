# Kapitalia integrado (React + Spring Boot + MySQL)

Este paquete contiene:
- `frontend/`: React 19 + Vite.
- `Backend_Kapitalia/`: API REST Spring Boot + JPA + MySQL.
- `Backend_Kapitalia/database/crear_base_datos.sql`: creación de la base `kapitalia`.

## Requisitos
- Java 17 o la versión indicada en `Backend_Kapitalia/pom.xml`.
- Maven.
- Node.js 20 o superior y npm.
- XAMPP con MySQL.

## 1. Crear la base de datos
1. Abre XAMPP e inicia **MySQL**.
2. Entra a `http://localhost/phpmyadmin`.
3. Importa `Backend_Kapitalia/database/crear_base_datos.sql`.
4. La base se llama `kapitalia`. Las tablas restantes se crean/actualizan al iniciar Spring Boot.

Si tu MySQL tiene contraseña, configura `DB_PASSWORD` antes de ejecutar Spring Boot. Por defecto usa `root` sin contraseña.

## 2. Iniciar el backend
1. Abre la carpeta `Backend_Kapitalia` en IntelliJ IDEA.
2. Espera a que Maven descargue las dependencias.
3. Revisa `src/main/resources/application.properties` si tu usuario/contraseña de MySQL son distintos.
4. Ejecuta `SistemaBancarioApplication.java`.
5. La API queda en `http://localhost:8080/api`.
6. Swagger: `http://localhost:8080/swagger-ui.html`.

## 3. Iniciar el frontend
1. Abre una terminal en `frontend`.
2. Ejecuta:
   ```bash
   npm install
   npm run dev
   ```
3. Abre la dirección local que muestre Vite (normalmente `http://localhost:5173`).

Vite reenvía `/api` al backend `http://localhost:8080`; por eso inicia Spring Boot antes de probar el registro y las operaciones.

## Qué se conectó en esta integración
- Al registrar un cliente desde el frontend, se comprueba que Spring Boot esté disponible.
- Se crean en MySQL una cuenta de ahorros, una cuenta corriente, una tarjeta débito y una tarjeta crédito.
- Se guardan los identificadores reales devueltos por la API para que el cliente opere sobre sus propias cuentas, en lugar de usar IDs globales fijos.
- Consignaciones, retiros, transferencias y pagos de tarjeta se envían al endpoint de transacciones del backend. Si el servidor falla, el frontend muestra el error y no simula que la operación quedó guardada.
- El dashboard sincroniza saldos e historial de las dos cuentas desde la API.

## Límites pendientes importantes
Esta es una integración de la capa bancaria, no una banca de producción:
- El registro de credenciales, el inicio de sesión, el perfil y la administración de clientes todavía usan `localStorage`; el backend entregado originalmente no incluye una API de clientes/autenticación. Por eso esos datos de usuario no quedan guardados en MySQL ni se comparten entre navegadores/equipos.
- Las compras con tarjeta y el cálculo de cuotas/deuda siguen en el frontend; no existe todavía un endpoint de compras ni una tabla de cuotas en el backend.
- El mapeo entre el usuario del navegador y los IDs de sus cuentas se guarda localmente. Para usarlo desde otro equipo hace falta implementar autenticación y relación cliente-cuenta en el backend.
- No usar con dinero real ni credenciales reales. Faltan autenticación segura, autorización por cliente, cifrado/gestión de contraseñas y controles de seguridad.

## Importante al probar
Registra un usuario nuevo con Spring Boot y MySQL ya iniciados. El usuario demo preexistente del frontend es local y no crea automáticamente registros de cuentas en MySQL.
