import { createContext, useContext, useMemo, useState } from 'react';
import { AuthService } from '../services/bank.js';

const AuthContext = createContext(null);

function readSession() {
  try {
    const session = JSON.parse(localStorage.getItem('clienteActivo') || 'null');
    if (!session?.id) return null;

    const customer = new AuthService().getCliente(session.id);
    return customer && !customer.bloqueado
      ? {
          id: customer.id,
          nombreCompleto: customer.nombreCompleto,
          usuario: customer.usuario,
          celular: customer.celular,
        }
      : null;
  } catch (error) {
    console.error('No se pudo restaurar la sesión:', error);
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(readSession);

  const value = useMemo(
    () => ({
      user,
      login(usuario, contrasena) {
        const customer = new AuthService().login(usuario.trim(), contrasena);
        const session = {
          id: customer.id,
          nombreCompleto: customer.nombreCompleto,
          usuario: customer.usuario,
          celular: customer.celular,
        };
        localStorage.setItem('clienteActivo', JSON.stringify(session));
        setUser(session);
      },
      register(datos) {
        new AuthService().registrar(datos);
      },
      updateProfile(datos) {
        const auth = new AuthService();
        const customer = auth.editar(user.id, datos);
        const session = {
          ...user,
          nombreCompleto: customer.nombreCompleto,
          celular: customer.celular,
        };
        localStorage.setItem('clienteActivo', JSON.stringify(session));
        setUser(session);
      },
      changePassword(actual, nueva) {
        const auth = new AuthService();
        const customer = auth.getCliente(user.id);
        if (!customer || customer.contrasena !== actual) {
          throw new Error('La contraseña actual es incorrecta.');
        }
        if (nueva.length < 4) {
          throw new Error('La nueva contraseña debe tener al menos 4 caracteres.');
        }
        auth.editar(user.id, { contrasena: nueva });
      },
      logout() {
        localStorage.removeItem('clienteActivo');
        setUser(null);
      },
    }),
    [user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth debe usarse dentro de AuthProvider.');
  return context;
}
