# Nuevo Banco Kapitalia

Aplicación de banca demostrativa migrada a React con Vite. Incluye inicio, registro, dashboard privado, administración de usuarios, cuentas de ahorro y corriente, transferencias, historial, tarjeta de crédito y perfil.

## Requisitos

- Node.js 20 o superior
- npm

## Iniciar

```bash
npm install
npm run dev
```

Para generar y revisar el build de producción:

```bash
npm run build
npm run preview
```

## Cuenta de demostración

- Usuario: `demo`
- Contraseña: `1234`

Los usuarios, sesiones y operaciones se guardan en `localStorage` del navegador, por lo que los datos son locales al dispositivo. Este proyecto es una demostración frontend y no debe usarse para administrar dinero real ni para almacenar credenciales de producción.

La ruta `/admin` está protegida para requerir una sesión iniciada. En esta demostración cualquier usuario con una sesión activa puede administrar los usuarios locales; no existe control de roles ni un backend de autorización.
