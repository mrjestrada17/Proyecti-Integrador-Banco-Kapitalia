# Frontend Kapitalia

Aplicación React + Vite. Consulta `../README_INTEGRACION.md` para iniciar el backend Spring Boot, MySQL/XAMPP y el frontend integrado.

Comandos:
```bash
npm install
npm run dev
```
