import { api } from './api.js';

export class Cliente {
    constructor(id, identificacion, nombreCompleto, celular, usuario, contrasena) {
        this.id = id;
        this.identificacion = identificacion;
        this.nombreCompleto = nombreCompleto;
        this.celular = celular;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.intentosFallidos = 0;
        this.bloqueado = false;
    }
}

export class CuentaAhorros {
    constructor(saldoInicial = 100000) {
        this.tipo = 'Ahorros';
        this.saldo = saldoInicial;
        this.movimientos = [];
        this.tasaInteres = 0.015; // 1.5% mensual
    }

    consignar(monto) {
        if (monto <= 0) throw new Error('❌ El monto debe ser mayor a cero');
        this.saldo += monto;
        this.movimientos.unshift({
            fecha: new Date().toLocaleString(),
            tipo: 'Consignación',
            valor: monto
        });
        return { saldo: this.saldo, mensaje: `✅ Consignación exitosa: $${monto.toLocaleString()}` };
    }

    retirar(monto) {
        const montoConInteres = monto * (1 + this.tasaInteres);
        if (montoConInteres > this.saldo) {
            throw new Error(`❌ Saldo insuficiente. Necesitas $${montoConInteres.toLocaleString()} (incluye 1.5% de interés)`);
        }
        this.saldo -= montoConInteres;
        this.movimientos.unshift({
            fecha: new Date().toLocaleString(),
            tipo: 'Retiro',
            valor: montoConInteres,
            interes: this.tasaInteres
        });
        return {
            saldo: this.saldo,
            mensaje: `✅ Retiro de $${monto.toLocaleString()} + interés 1.5% ($${(monto * this.tasaInteres).toLocaleString()}) = Total $${montoConInteres.toLocaleString()}`
        };
    }

    consultarSaldo() {
        return this.saldo;
    }

    getMovimientos() {
        return this.movimientos;
    }
}

export class CuentaCorriente {
    constructor(saldoInicial = 50000) {
        this.tipo = 'Corriente';
        this.saldo = saldoInicial;
        this.movimientos = [];
        this.sobregiroPorcentaje = 0.20;
    }

    consignar(monto) {
        if (monto <= 0) throw new Error('❌ El monto debe ser mayor a cero');
        this.saldo += monto;
        this.movimientos.unshift({
            fecha: new Date().toLocaleString(),
            tipo: 'Consignación',
            valor: monto
        });
        return { saldo: this.saldo, mensaje: `✅ Consignación exitosa: $${monto.toLocaleString()}` };
    }

    retirar(monto) {
        const limiteRetiro = this.saldo * (1 + this.sobregiroPorcentaje);
        if (monto > limiteRetiro) {
            throw new Error(`❌ Monto excede el límite. Puedes retirar hasta $${limiteRetiro.toLocaleString()} (incluye 20% de sobregiro)`);
        }
        const usandoSobregiro = monto > this.saldo;
        const sobregiroUsado = usandoSobregiro ? (monto - this.saldo) : 0;
        this.saldo -= monto;
        this.movimientos.unshift({
            fecha: new Date().toLocaleString(),
            tipo: 'Retiro',
            valor: monto,
            sobregiro: usandoSobregiro,
            sobregiroUsado: sobregiroUsado
        });

        let mensaje = `✅ Retiro de $${monto.toLocaleString()}`;
        if (usandoSobregiro) {
            mensaje += ` (incluye $${sobregiroUsado.toLocaleString()} de sobregiro)`;
        }
        return { saldo: this.saldo, mensaje: mensaje };
    }

    consultarSaldo() {
        return this.saldo;
    }

    getLimiteRetiro() {
        return this.saldo * (1 + this.sobregiroPorcentaje);
    }

    getMovimientos() {
        return this.movimientos;
    }
}

export class TarjetaCredito {
    constructor(cupo = 500000) {
        this.cupo = cupo;
        this.deuda = 0;
        this.compras = [];
    }

    getCupoDisponible() {
        return Math.max(0, this.cupo - this.deuda);
    }

    calcularCuotaMensual(capital, cuotas, tasaMensual) {
        if (tasaMensual === 0) {
            return capital / cuotas;
        }
        const numerador = capital * tasaMensual;
        const denominador = 1 - Math.pow(1 + tasaMensual, -cuotas);
        return numerador / denominador;
    }

    getTasa(cuotas) {
        if (cuotas <= 2) {
            return { tasa: 0, texto: '0%', observacion: 'Sin interés' };
        } else if (cuotas <= 6) {
            return { tasa: 0.019, texto: '1.9%', observacion: 'Interés moderado' };
        } else {
            return { tasa: 0.023, texto: '2.3%', observacion: 'Interés alto' };
        }
    }

    comprar(monto, cuotas) {
        if (monto <= 0) throw new Error('❌ Monto inválido');
        if (monto > this.getCupoDisponible()) {
            throw new Error(`❌ Cupo insuficiente. Disponible: $${this.getCupoDisponible().toLocaleString()}`);
        }

        const { tasa, texto, observacion } = this.getTasa(cuotas);
        const cuotaMensual = this.calcularCuotaMensual(monto, cuotas, tasa);
        const totalDeuda = cuotaMensual * cuotas;
        const interesTotal = totalDeuda - monto;

        this.deuda += totalDeuda;

        const compra = {
            fecha: new Date().toLocaleString(),
            monto: monto,
            cuotas: cuotas,
            tasa: texto,
            interesTotal: interesTotal,
            totalDeuda: totalDeuda,
            cuotaMensual: cuotaMensual,
            observacion: observacion
        };
        this.compras.unshift(compra);

        return {
            mensaje: `💳 Compra de $${monto.toLocaleString()} en ${cuotas} cuotas\n📊 Tasa: ${texto} mensual (${observacion})\n💰 Interés total: $${interesTotal.toLocaleString()}\n📅 Cuota mensual: $${cuotaMensual.toFixed(2)}`,
            cuotaMensual: cuotaMensual,
            interesTotal: interesTotal,
            totalDeuda: totalDeuda
        };
    }

    pagar(monto) {
        if (monto <= 0) throw new Error('❌ Monto inválido');
        if (monto > this.deuda) throw new Error(`❌ El monto excede la deuda actual ($${this.deuda.toLocaleString()})`);
        this.deuda -= monto;
        return {
            deuda: this.deuda,
            mensaje: `✅ Pago de $${monto.toLocaleString()} realizado. Deuda restante: $${this.deuda.toLocaleString()}`
        };
    }

    getCompras() {
        return this.compras;
    }
}

export class AuthService {
    constructor() {
        this.clientes = this.cargarClientes();
    }

    cargarClientes() {
        const data = localStorage.getItem('clientes');
        if (data) {
            const parsed = JSON.parse(data);
            return parsed.map(c => {
                const cliente = new Cliente(c.id, c.identificacion, c.nombreCompleto, c.celular, c.usuario, c.contrasena);
                cliente.intentosFallidos = c.intentosFallidos || 0;
                cliente.bloqueado = c.bloqueado || false;
                return cliente;
            });
        }
        return [new Cliente(1, '123456', 'Usuario Demo', '3001234567', 'demo', '1234')];
    }

    guardar() {
        localStorage.setItem('clientes', JSON.stringify(this.clientes));
    }

    async registrar(datos) {
        const existe = this.clientes.find(c => c.usuario === datos.usuario);
        if (existe) throw new Error('❌ El nombre de usuario ya está registrado');

        const existeId = this.clientes.find(c => c.identificacion === datos.identificacion);
        if (existeId) throw new Error('❌ Ya existe un cliente con esta identificación');

        // La cuenta y las tarjetas se crean primero en MySQL. Si la API no responde,
        // no se confirma un registro que solo exista en el navegador.
        if (!(await api.checkHealth())) {
            throw new Error('No hay conexión con el servidor Kapitalia. Inicia MySQL y Spring Boot e inténtalo nuevamente.');
        }

        const nuevo = new Cliente(
            Date.now(),
            datos.identificacion,
            datos.nombreCompleto,
            datos.celular,
            datos.usuario,
            datos.contrasena
        );

        const sufijo = String(nuevo.id).slice(-8).padStart(8, '0');
        const cuentaAhorros = await api.crearCuenta({
            numeroCuenta: `10${sufijo}01`,
            tipoCuenta: 'Ahorros',
            saldoDisponible: 100000,
            estado: 'Activa'
        });
        const cuentaCorriente = await api.crearCuenta({
            numeroCuenta: `20${sufijo}02`,
            tipoCuenta: 'Corriente',
            saldoDisponible: 50000,
            estado: 'Activa'
        });

        const tarjetaDebito = await api.crearTarjeta({
            idCuenta: cuentaAhorros.idCuenta,
            numeroTarjeta: `4532${sufijo}11`,
            tipoTarjeta: 'Debito',
            fechaVencimiento: '2029-12-31'
        });
        const tarjetaCredito = await api.crearTarjeta({
            idCuenta: cuentaCorriente.idCuenta,
            numeroTarjeta: `5412${sufijo}22`,
            tipoTarjeta: 'Credito',
            cupoAvance: 500000,
            fechaVencimiento: '2028-12-31'
        });

        const mapping = {
            ahorrosId: cuentaAhorros.idCuenta,
            corrienteId: cuentaCorriente.idCuenta,
            tarjetaDebitoId: tarjetaDebito.idTarjeta,
            tarjetaCreditoId: tarjetaCredito.idTarjeta
        };

        this.clientes.push(nuevo);
        this.guardar();
        this.inicializarCuentasCliente(nuevo.id);
        localStorage.setItem(`backend_map_${nuevo.id}`, JSON.stringify(mapping));
        return nuevo;
    }

    inicializarCuentasCliente(clienteId) {
        const cuentas = {
            ahorros: new CuentaAhorros(100000),
            corriente: new CuentaCorriente(50000)
        };
        localStorage.setItem(`cuentas_${clienteId}`, JSON.stringify(cuentas));

        const tarjeta = new TarjetaCredito(500000);
        localStorage.setItem(`tarjeta_${clienteId}`, JSON.stringify({ deuda: tarjeta.deuda, compras: tarjeta.compras }));
    }

    login(usuario, contrasena) {
        const cliente = this.clientes.find(c => c.usuario === usuario);
        if (!cliente) {
            throw new Error('❌ Usuario no encontrado');
        }
        if (cliente.bloqueado) {
            throw new Error('🔒 Cuenta bloqueada. Contacte al administrador');
        }
        if (cliente.contrasena !== contrasena) {
            cliente.intentosFallidos++;
            this.guardar();
            const restantes = 3 - cliente.intentosFallidos;
            if (cliente.intentosFallidos >= 3) {
                cliente.bloqueado = true;
                this.guardar();
                throw new Error('🔒 Cuenta bloqueada por 3 intentos fallidos');
            }
            throw new Error(`❌ Contraseña incorrecta. Intentos restantes: ${restantes}`);
        }
        cliente.intentosFallidos = 0;
        this.guardar();
        return cliente;
    }

    getCliente(id) {
        return this.clientes.find(c => c.id == id);
    }

    editar(id, datos) {
        const cliente = this.clientes.find(c => c.id == id);
        if (cliente) {
            if (datos.nombreCompleto) cliente.nombreCompleto = datos.nombreCompleto;
            if (datos.celular) cliente.celular = datos.celular;
            if (datos.contrasena) cliente.contrasena = datos.contrasena;
            this.guardar();
            return cliente;
        }
        throw new Error('❌ Cliente no encontrado');
    }

    eliminar(id) {
        const index = this.clientes.findIndex(c => c.id == id);
        if (index !== -1) {
            this.clientes.splice(index, 1);
            this.guardar();
            localStorage.removeItem(`cuentas_${id}`);
            localStorage.removeItem(`tarjeta_${id}`);
            localStorage.removeItem(`backend_map_${id}`);
        }
    }

    getAllClientes() {
        return this.clientes;
    }
}

export class BancoService {
    constructor(clienteId) {
        this.clienteId = clienteId;
        this.cuentas = this.cargarCuentas();
        this.tarjeta = this.cargarTarjeta();
        this.backendMap = this.cargarBackendMap();
        this.apiConnected = false;
    }

    cargarBackendMap() {
        const key = `backend_map_${this.clienteId}`;
        const data = localStorage.getItem(key);
        if (data) {
            try { return JSON.parse(data); } catch { /* ignore */ }
        }
        // Asignación inteligente por defecto: cliente 1 mapea a cuentas 1 y 2 en H2/MySQL
        return {
            ahorrosId: this.clienteId === 1 ? 1 : 1,
            corrienteId: this.clienteId === 1 ? 2 : 2,
            tarjetaDebitoId: 1,
            tarjetaCreditoId: 2
        };
    }

    isApiConnected() {
        return this.apiConnected;
    }

    /**
     * Sincroniza datos desde la Base de Datos del Backend Spring Boot (API)
     */
    async syncFromBackend() {
        try {
            const isOnline = await api.checkHealth();
            this.apiConnected = isOnline;

            if (!isOnline) {
                return false;
            }

            // Consultar saldo de cuenta Ahorros
            if (this.backendMap.ahorrosId) {
                const cuentaAhorros = await api.getCuenta(this.backendMap.ahorrosId).catch(() => null);
                if (cuentaAhorros && typeof cuentaAhorros.saldoDisponible === 'number') {
                    this.cuentas.ahorros.saldo = Number(cuentaAhorros.saldoDisponible);
                }
            }

            // Consultar saldo de cuenta Corriente
            if (this.backendMap.corrienteId) {
                const cuentaCorriente = await api.getCuenta(this.backendMap.corrienteId).catch(() => null);
                if (cuentaCorriente && typeof cuentaCorriente.saldoDisponible === 'number') {
                    this.cuentas.corriente.saldo = Number(cuentaCorriente.saldoDisponible);
                }
            }

            // Consultar tarjeta de crédito y cupo disponible
            if (this.backendMap.tarjetaCreditoId) {
                const tarjeta = await api.getTarjetas().then(list => list.find(t => t.idTarjeta === this.backendMap.tarjetaCreditoId)).catch(() => null);
                if (tarjeta && tarjeta.cupoAvance != null) {
                    this.tarjeta.cupo = Number(tarjeta.cupoAvance);
                }
            }

            // Consultar historial de ambas cuentas en MySQL
            const accountHistory = [
                { id: this.backendMap.ahorrosId, key: 'ahorros', label: 'Ahorros' },
                { id: this.backendMap.corrienteId, key: 'corriente', label: 'Corriente' }
            ];
            for (const account of accountHistory) {
                if (!account.id) continue;
                const txList = await api.getTransaccionesPorCuenta(account.id).catch(() => []);
                if (Array.isArray(txList)) {
                    const mappedMovements = txList.map(tx => ({
                        fecha: new Date(tx.fechaHora).toLocaleString(),
                        tipo: `${tx.nombreOperacion} (Cajero: ${tx.codigoCajero})`,
                        valor: Number(tx.monto),
                        cuenta: account.label,
                        txId: tx.idTransaccion
                    }));
                    const existingTxs = new Set(this.cuentas[account.key].movimientos.map(m => m.txId).filter(Boolean));
                    const newOnes = mappedMovements.filter(m => !existingTxs.has(m.txId));
                    this.cuentas[account.key].movimientos = [...newOnes, ...this.cuentas[account.key].movimientos];
                }
            }

            this.guardar();
            return true;
        } catch (error) {
            console.warn('Sincronización con backend falló:', error);
            this.apiConnected = false;
            return false;
        }
    }

    cargarCuentas() {
        const key = `cuentas_${this.clienteId}`;
        const data = localStorage.getItem(key);
        if (data) {
            try {
                const parsed = JSON.parse(data);
                const ahorros = new CuentaAhorros();
                const corriente = new CuentaCorriente();
                ahorros.saldo = parsed.ahorros?.saldo ?? 100000;
                ahorros.movimientos = parsed.ahorros?.movimientos || [];
                corriente.saldo = parsed.corriente?.saldo ?? 50000;
                corriente.movimientos = parsed.corriente?.movimientos || [];
                return { ahorros, corriente };
            } catch { /* ignore */ }
        }
        return {
            ahorros: new CuentaAhorros(100000),
            corriente: new CuentaCorriente(50000)
        };
    }

    cargarTarjeta() {
        const key = `tarjeta_${this.clienteId}`;
        const data = localStorage.getItem(key);
        if (data) {
            try {
                const parsed = JSON.parse(data);
                const tarjeta = new TarjetaCredito(500000);
                tarjeta.deuda = parsed.deuda || 0;
                tarjeta.compras = parsed.compras || [];
                return tarjeta;
            } catch { /* ignore */ }
        }
        return new TarjetaCredito(500000);
    }

    guardar() {
        localStorage.setItem(`cuentas_${this.clienteId}`, JSON.stringify(this.cuentas));
        localStorage.setItem(`tarjeta_${this.clienteId}`, JSON.stringify({
            deuda: this.tarjeta.deuda,
            compras: this.tarjeta.compras
        }));
    }

    /**
     * Consignar fondos: Consume endpoint POST /api/transacciones (Tipo 1: Consignación)
     */
    async consignar(tipo, monto) {
        if (!monto || monto <= 0) throw new Error('❌ El monto debe ser mayor a cero');

        const cuenta = this.cuentas[tipo];
        const cuentaId = tipo === 'ahorros' ? this.backendMap.ahorrosId : this.backendMap.corrienteId;
        const tarjetaId = tipo === 'ahorros' ? this.backendMap.tarjetaDebitoId : this.backendMap.tarjetaCreditoId;

        try {
            // Intentar ejecutar transacción directamente en el Backend Spring Boot
            const txResponse = await api.procesarTransaccion({
                idTarjeta: tarjetaId || 1,
                idTipoOperacion: 1, // Consignación
                idCuentaOrigen: cuentaId || 1,
                monto: monto,
                codigoCajero: 'ATM-KAP01'
            });

            this.apiConnected = true;
            if (txResponse && txResponse.saldoNuevoOrigen != null) {
                cuenta.saldo = Number(txResponse.saldoNuevoOrigen);
            } else {
                cuenta.saldo += monto;
            }

            cuenta.movimientos.unshift({
                fecha: new Date().toLocaleString(),
                tipo: `Consignación (TX #${txResponse.idTransaccion})`,
                valor: monto,
                txId: txResponse.idTransaccion
            });

            this.guardar();
            return {
                saldo: cuenta.saldo,
                mensaje: `✅ Consignación exitosa: $${monto.toLocaleString()} [BD Spring Boot: TX #${txResponse.idTransaccion}]`
            };
        } catch (apiError) {
            throw new Error(apiError.message || 'No fue posible registrar la consignación en la base de datos.');
        }
    }

    /**
     * Retirar fondos: Consume endpoint POST /api/transacciones (Tipo 2: Retiro)
     */
    async retirar(tipo, monto) {
        if (!monto || monto <= 0) throw new Error('❌ El monto debe ser mayor a cero');

        const cuenta = this.cuentas[tipo];
        const cuentaId = tipo === 'ahorros' ? this.backendMap.ahorrosId : this.backendMap.corrienteId;
        const tarjetaId = tipo === 'ahorros' ? this.backendMap.tarjetaDebitoId : this.backendMap.tarjetaCreditoId;

        try {
            // Validar límites antes de enviar
            if (tipo === 'ahorros') {
                const totalConInteres = monto * (1 + cuenta.tasaInteres);
                if (totalConInteres > cuenta.saldo) {
                    throw new Error(`❌ Saldo insuficiente. Necesitas $${totalConInteres.toLocaleString()} (incluye 1.5% de interés)`);
                }
            } else {
                const limite = cuenta.getLimiteRetiro();
                if (monto > limite) {
                    throw new Error(`❌ Monto excede el límite. Puedes retirar hasta $${limite.toLocaleString()} (incluye 20% sobregiro)`);
                }
            }

            // Enviar a la API Spring Boot
            const txResponse = await api.procesarTransaccion({
                idTarjeta: tarjetaId || 1,
                idTipoOperacion: 2, // Retiro
                idCuentaOrigen: cuentaId || 1,
                monto: monto,
                codigoCajero: 'ATM-KAP01'
            });

            this.apiConnected = true;
            if (txResponse && txResponse.saldoNuevoOrigen != null) {
                cuenta.saldo = Number(txResponse.saldoNuevoOrigen);
            } else {
                cuenta.saldo -= monto;
            }

            cuenta.movimientos.unshift({
                fecha: new Date().toLocaleString(),
                tipo: `Retiro ATM (TX #${txResponse.idTransaccion})`,
                valor: monto,
                txId: txResponse.idTransaccion
            });

            this.guardar();
            return {
                saldo: cuenta.saldo,
                mensaje: `✅ Retiro de $${monto.toLocaleString()} exitoso en Cajero ATM [TX #${txResponse.idTransaccion}]`
            };
        } catch (error) {
            if (error.message.includes('insuficiente') || error.message.includes('límite') || error.message.includes('Bloqueada')) {
                throw error;
            }
            throw new Error(error.message || 'No fue posible registrar el retiro en la base de datos.');
        }
    }

    getSaldo(tipo) {
        return this.cuentas[tipo].consultarSaldo();
    }

    getLimiteRetiro(tipo) {
        if (tipo === 'corriente') {
            return this.cuentas.corriente.getLimiteRetiro();
        }
        return this.cuentas.ahorros.consultarSaldo();
    }

    /**
     * Transferir fondos: Consume endpoint POST /api/transacciones (Tipo 3: Transf. Enviada)
     */
    async transferir(origen, destino, monto, usuarioDestino = null) {
        if (!monto || monto <= 0) throw new Error('❌ El monto debe ser mayor a cero');
        if (origen === destino && !usuarioDestino) {
            throw new Error('❌ No puedes transferir al mismo producto');
        }

        const idOrigen = origen === 'ahorros' ? this.backendMap.ahorrosId : this.backendMap.corrienteId;
        let idDestino = destino === 'ahorros' ? this.backendMap.ahorrosId : this.backendMap.corrienteId;

        if (usuarioDestino) {
            const authService = new AuthService();
            const clienteDestino = authService.clientes.find(c => c.usuario === usuarioDestino);
            if (!clienteDestino) throw new Error('❌ Usuario destino no encontrado');
            const destinoMap = JSON.parse(localStorage.getItem(`backend_map_${clienteDestino.id}`) || 'null');
            if (!destinoMap) throw new Error('El usuario destino todavía no tiene cuentas registradas en el servidor.');
            idDestino = destinoMap.ahorrosId;
        }

        try {
            const txResponse = await api.procesarTransaccion({
                idTarjeta: this.backendMap.tarjetaDebitoId || 1,
                idTipoOperacion: 3, // Transf. Enviada
                idCuentaOrigen: idOrigen || 1,
                idCuentaDestino: idDestino || 2,
                monto: monto,
                codigoCajero: 'ATM-KAP01'
            });

            this.apiConnected = true;

            // Actualizar saldo origen
            if (txResponse.saldoNuevoOrigen != null) {
                this.cuentas[origen].saldo = Number(txResponse.saldoNuevoOrigen);
            } else {
                this.cuentas[origen].saldo -= monto;
            }

            // Si es entre cuentas propias, acreditar destino
            if (!usuarioDestino && this.cuentas[destino]) {
                this.cuentas[destino].saldo += monto;
            }

            this.cuentas[origen].movimientos.unshift({
                fecha: new Date().toLocaleString(),
                tipo: usuarioDestino ? `Transferencia enviada a ${usuarioDestino}` : `Transferencia a ${destino}`,
                valor: monto,
                txId: txResponse.idTransaccion
            });

            this.guardar();
            return {
                mensaje: `✅ Transferencia de $${monto.toLocaleString()} exitosa [BD Spring Boot: TX #${txResponse.idTransaccion}]`
            };
        } catch (error) {
            if (error.message.includes('insuficiente') || error.message.includes('Bloqueada')) {
                throw error;
            }
            throw new Error(error.message || 'No fue posible registrar la transferencia en la base de datos.');
        }
    }

    getMovimientos(tipo = null) {
        if (tipo && tipo !== 'todos') {
            return this.cuentas[tipo].movimientos;
        }
        const todos = [
            ...this.cuentas.ahorros.movimientos.map(m => ({ ...m, cuenta: 'Ahorros' })),
            ...this.cuentas.corriente.movimientos.map(m => ({ ...m, cuenta: 'Corriente' }))
        ];
        return todos.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
    }

    realizarCompra(monto, cuotas) {
        const resultado = this.tarjeta.comprar(monto, cuotas);
        this.guardar();
        return resultado;
    }

    /**
     * Pago de tarjeta: Consume endpoint POST /api/transacciones (Tipo 5: Pago Tarjeta)
     */
    async pagarTarjeta(monto) {
        if (!monto || monto <= 0) throw new Error('❌ Monto inválido');

        try {
            const txResponse = await api.procesarTransaccion({
                idTarjeta: this.backendMap.tarjetaCreditoId || 2,
                idTipoOperacion: 5, // Pago Tarjeta
                idCuentaOrigen: this.backendMap.ahorrosId || 1,
                monto: monto,
                codigoCajero: 'ATM-KAP01'
            });

            this.apiConnected = true;
            if (txResponse.saldoNuevoOrigen != null) {
                this.cuentas.ahorros.saldo = Number(txResponse.saldoNuevoOrigen);
            }
            this.tarjeta.deuda = Math.max(0, this.tarjeta.deuda - monto);
            this.guardar();

            return {
                deuda: this.tarjeta.deuda,
                mensaje: `✅ Pago de tarjeta por $${monto.toLocaleString()} registrado en BD Spring Boot [TX #${txResponse.idTransaccion}]`
            };
        } catch (error) {
            throw new Error(error.message || 'No fue posible registrar el pago en la base de datos.');
        }
    }

    getTarjetaInfo() {
        return {
            cupoTotal: this.tarjeta.cupo,
            cupoDisponible: this.tarjeta.getCupoDisponible(),
            deuda: this.tarjeta.deuda,
            compras: this.tarjeta.compras
        };
    }
}
