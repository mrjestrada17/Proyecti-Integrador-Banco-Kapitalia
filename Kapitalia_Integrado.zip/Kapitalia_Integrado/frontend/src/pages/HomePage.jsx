import { Link } from 'react-router-dom';
import Brand from '../components/Brand.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const products = [
  { icon: '◈', title: 'Cuenta de ahorros', text: 'Haz crecer tu dinero con una cuenta hecha para tus metas.' },
  { icon: '↗', title: 'Cuenta corriente', text: 'Controla tus gastos diarios con flexibilidad y respaldo.' },
  { icon: '▣', title: 'Tarjeta de crédito', text: 'Compra a tu ritmo y administra tus cuotas desde un solo lugar.' },
];

export default function HomePage() {
  const { user, logout } = useAuth();

  return (
    <div className="landing">
      <header className="site-header">
        <div className="header-inner">
          <Brand />
          <nav className="header-nav" aria-label="Navegación principal">
            <a href="#productos">Productos</a>
            {user ? (
              <>
                <Link to="/dashboard">Mi cuenta</Link>
                <button className="text-button" type="button" onClick={logout}>Cerrar sesión</button>
              </>
            ) : (
              <>
                <Link to="/login">Iniciar sesión</Link>
                <Link className="button button-small" to="/registro">Abrir cuenta</Link>
              </>
            )}
          </nav>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="hero-content">
            <span className="eyebrow"><span className="status-dot" /> TU BANCO, A TU MANERA</span>
            <h1>Tu futuro financiero comienza <em>hoy.</em></h1>
            <p>Una forma más sencilla de ahorrar, gestionar tu dinero y avanzar hacia tus metas.</p>
            <div className="hero-actions">
              <Link className="button" to={user ? '/dashboard' : '/registro'}>{user ? 'Ir a mi cuenta' : 'Abre tu cuenta gratis'} <span>→</span></Link>
              {!user && <Link className="button button-outline" to="/login">Ya soy cliente</Link>}
            </div>
            <div className="hero-note"><span className="secure-icon">✓</span> Sin papeleo. En pocos minutos.</div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="hero-card">
              <div className="hero-card-top"><span className="card-chip" /><span>Kapitalia</span></div>
              <div className="hero-card-number">•••• &nbsp;•••• &nbsp;•••• &nbsp;4829</div>
              <div className="hero-card-bottom"><span>CLIENTE KAPITALIA</span><span>VISA</span></div>
            </div>
            <div className="floating-stat"><span>Saldo total</span><strong>$1.250.000</strong><small>↑ Tu dinero, en movimiento</small></div>
            <span className="art-spark spark-one">✳</span>
            <span className="art-spark spark-two">✦</span>
          </div>
        </section>

        <section className="products-section" id="productos">
          <div className="section-heading">
            <span className="eyebrow">TODO LO QUE NECESITAS</span>
            <h2>Finanzas que se mueven contigo.</h2>
            <p>Soluciones simples para cada momento de tu vida.</p>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <article className="product-card" key={product.title}>
                <span className="product-icon">{product.icon}</span>
                <h3>{product.title}</h3>
                <p>{product.text}</p>
                <Link to={user ? '/dashboard' : '/registro'} aria-label={`Conocer ${product.title}`}>Explorar <span>→</span></Link>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="site-footer"><Brand light /><span>© 2026 Kapitalia. Tu confianza nos mueve.</span></footer>
    </div>
  );
}
