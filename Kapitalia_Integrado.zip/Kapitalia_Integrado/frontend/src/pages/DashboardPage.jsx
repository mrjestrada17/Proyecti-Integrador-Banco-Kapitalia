import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Brand from '../components/Brand.jsx';
import Toast from '../components/Toast.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { BancoService } from '../services/bank.js';

const navigation = [
  { id: 'resumen', label: 'Resumen', icon: '▦' },
  { id: 'operaciones', label: 'Operaciones', icon: '↔' },
  { id: 'transferir', label: 'Transferir', icon: '⇄' },
  { id: 'tarjeta', label: 'Tarjeta de crédito', icon: '▣' },
  { id: 'movimientos', label: 'Movimientos', icon: '◷' },
  { id: 'perfil', label: 'Mi perfil', icon: '◉' },
];

const currency = (amount) => `$${Number(amount || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}`;

function DashboardPage() {
  const { user, logout, updateProfile, changePassword } = useAuth();
  const bank = useMemo(() => new BancoService(user.id), [user.id]);
  const [section, setSection] = useState('resumen');
  const [filter, setFilter] = useState('todos');
  const [balances, setBalances] = useState({ ahorros: 0, corriente: 0, limiteCorriente: 0 });
  const [movements, setMovements] = useState([]);
  const [card, setCard] = useState({ cupoTotal: 500000, cupoDisponible: 500000, deuda: 0, compras: [] });
  const [toast, setToast] = useState(null);
  const [destination, setDestination] = useState('ahorros');
  const [operationPreset, setOperationPreset] = useState({ account: 'ahorros', operation: 'consignar' });
  const [isApiOnline, setIsApiOnline] = useState(false);

  async function refresh() {
    await bank.syncFromBackend();
    setBalances({
      ahorros: bank.getSaldo('ahorros'),
      corriente: bank.getSaldo('corriente'),
      limiteCorriente: bank.getLimiteRetiro('corriente'),
    });
    setMovements(bank.getMovimientos(filter));
    setCard(bank.getTarjetaInfo());
    setIsApiOnline(bank.isApiConnected());
  }

  useEffect(() => {
    refresh();
  }, [bank, filter]);

  function notify(message, type = 'success') {
    setToast({ message, type });
    window.setTimeout(() => setToast(null), 4500);
  }

  async function runBankAction(action) {
    try {
      const result = await action();
      await refresh();
      notify(result?.mensaje || 'Operación realizada correctamente.');
      return true;
    } catch (error) {
      notify(error.message || 'No se pudo completar la operación.', 'error');
      return false;
    }
  }

  async function handleAccountOperation(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const amount = Number(data.get('monto'));
    const account = data.get('cuenta');
    const operation = data.get('operacion');
    if (!Number.isFinite(amount) || amount <= 0) {
      notify('Ingresa un monto mayor que cero.', 'error');
      return;
    }
    const completed = await runBankAction(() => (
      operation === 'consignar' ? bank.consignar(account, amount) : bank.retirar(account, amount)
    ));
    if (completed) event.currentTarget.reset();
  }

  function openAccountOperation(account, operation) {
    setOperationPreset({ account, operation });
    setSection('operaciones');
  }

  async function handleTransfer(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const amount = Number(data.get('monto'));
    const origin = data.get('origen');
    const target = data.get('destino');
    if (!Number.isFinite(amount) || amount <= 0) {
      notify('Ingresa un monto mayor que cero.', 'error');
      return;
    }
    if (target === 'otro') {
      const username = String(data.get('usuarioDestino') || '').trim();
      if (!username) {
        notify('Ingresa el usuario al que deseas transferir.', 'error');
        return;
      }
      if (username === user.usuario) {
        notify('Elige otro usuario para hacer la transferencia.', 'error');
        return;
      }
      if (await runBankAction(() => bank.transferir(origin, 'ahorros', amount, username))) event.currentTarget.reset();
    } else if (await runBankAction(() => bank.transferir(origin, target, amount))) {
      event.currentTarget.reset();
    }
  }

  async function handlePurchase(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const amount = Number(data.get('compra'));
    const installments = Number(data.get('cuotas'));
    if (!Number.isFinite(amount) || amount <= 0) {
      notify('Ingresa un monto mayor que cero.', 'error');
      return;
    }
    if (await runBankAction(() => bank.realizarCompra(amount, installments))) event.currentTarget.reset();
  }

  async function handlePayment(event) {
    event.preventDefault();
    const amount = Number(new FormData(event.currentTarget).get('pago'));
    if (!Number.isFinite(amount) || amount <= 0) {
      notify('Ingresa un monto mayor que cero.', 'error');
      return;
    }
    if (await runBankAction(() => bank.pagarTarjeta(amount))) event.currentTarget.reset();
  }

  function handleProfile(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const nombreCompleto = String(data.get('nombreCompleto')).trim();
    const celular = String(data.get('celular')).trim();
    if (!nombreCompleto || !celular) {
      notify('Completa tu nombre y número de celular.', 'error');
      return;
    }
    try {
      updateProfile({ nombreCompleto, celular });
      notify('Tu perfil se actualizó correctamente.');
    } catch (error) {
      notify(error.message, 'error');
    }
  }

  function handlePassword(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const current = String(data.get('actual'));
    const next = String(data.get('nueva'));
    if (next !== data.get('confirmar')) {
      notify('Las nuevas contraseñas no coinciden.', 'error');
      return;
    }
    try {
      changePassword(current, next);
      event.currentTarget.reset();
      notify('Tu contraseña se cambió correctamente.');
    } catch (error) {
      notify(error.message, 'error');
    }
  }

  const total = balances.ahorros + balances.corriente;

  return (
    <div className="dashboard-shell">
      <header className="dashboard-topbar">
        <Brand />
        <div className="topbar-actions">
          <span 
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '13px',
              padding: '4px 10px',
              borderRadius: '20px',
              backgroundColor: isApiOnline ? 'rgba(16, 185, 129, 0.12)' : 'rgba(245, 158, 11, 0.12)',
              color: isApiOnline ? '#059669' : '#d97706',
              fontWeight: 600,
              border: `1px solid ${isApiOnline ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)'}`
            }}
            title={isApiOnline ? 'Conectado a la API REST Spring Boot (http://localhost:8080/api)' : 'Backend Spring Boot no detectado en el puerto 8080. Trabajando en modo local.'}
          >
            {isApiOnline ? '🟢 API Spring Boot Conectada' : '🟠 Modo Local'}
          </span>
          <span className="welcome-name">Hola, {user.nombreCompleto.split(' ')[0]}</span>
          <button className="button button-outline button-small" type="button" onClick={logout}>Cerrar sesión</button>
        </div>
      </header>
      <div className="dashboard-layout">
        <aside className="dashboard-sidebar">
          <div className="sidebar-customer">
            <div className="avatar">{user.nombreCompleto.trim().charAt(0).toUpperCase()}</div>
            <div><strong>{user.nombreCompleto}</strong><span>Cliente Kapitalia</span></div>
          </div>
          <span className="sidebar-caption">MI ESPACIO</span>
          <nav className="dashboard-nav" aria-label="Menú de cuenta">
            {navigation.map((item) => (
              <button
                className={section === item.id ? 'selected' : ''}
                type="button"
                key={item.id}
                onClick={() => setSection(item.id)}
              >
                <span className="nav-icon">{item.icon}</span>{item.label}
                {section === item.id && <span className="nav-current" />}
              </button>
            ))}
          </nav>
          <Link className="admin-nav-link" to="/admin"><span className="nav-icon">⚙</span>Administración</Link>
          <div className="sidebar-help"><span>¿Necesitas ayuda?</span><strong>Estamos aquí para ti.</strong></div>
        </aside>

        <main className="dashboard-content">
          <div className="dashboard-heading">
            <div>
              <span className="eyebrow">TU ESPACIO FINANCIERO</span>
              <h1>{navigation.find((item) => item.id === section)?.label}</h1>
            </div>
            <span className="today-date">{new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
          </div>

          {section === 'resumen' && (
            <section className="dashboard-section">
              <div className="balance-banner">
                <div><span>Saldo total en tus cuentas</span><strong>{currency(total)}</strong><small>Tus finanzas, siempre a la vista.</small></div>
                <div className="balance-mark" aria-hidden="true">K</div>
              </div>
              <div className="account-grid">
                <article className="account-tile">
                  <div className="tile-top"><span className="tile-icon">◈</span><span className="account-status">ACTIVA</span></div>
                  <h2>Cuenta de ahorros</h2><span className="account-number">•••• •••• 0182</span>
                  <strong className="account-amount">{currency(balances.ahorros)}</strong>
                  <p>Interés del 1,5% aplicado en retiros</p>
                  <div className="tile-actions"><button type="button" onClick={() => openAccountOperation('ahorros', 'consignar')}>Consignar</button><button type="button" onClick={() => openAccountOperation('ahorros', 'retirar')}>Retirar</button></div>
                </article>
                <article className="account-tile">
                  <div className="tile-top"><span className="tile-icon tile-icon-alt">↗</span><span className="account-status">ACTIVA</span></div>
                  <h2>Cuenta corriente</h2><span className="account-number">•••• •••• 3490</span>
                  <strong className="account-amount">{currency(balances.corriente)}</strong>
                  <p>Límite de retiro: {currency(balances.limiteCorriente)}</p>
                  <div className="tile-actions"><button type="button" onClick={() => openAccountOperation('corriente', 'consignar')}>Consignar</button><button type="button" onClick={() => openAccountOperation('corriente', 'retirar')}>Retirar</button></div>
                </article>
              </div>
              <div className="recent-panel">
                <div className="panel-heading"><div><span className="eyebrow">ACTIVIDAD</span><h2>Movimientos recientes</h2></div><button className="link-button" type="button" onClick={() => setSection('movimientos')}>Ver todos →</button></div>
                <MovementList movements={movements.slice(0, 4)} />
              </div>
            </section>
          )}

          {section === 'operaciones' && (
            <section className="dashboard-section">
              <div className="section-intro"><h2>Gestiona tus cuentas</h2><p>Consigna o retira dinero de manera sencilla.</p></div>
              <div className="account-grid compact-grid">
                <article className="account-tile"><span className="eyebrow">CUENTA DE AHORROS</span><strong className="account-amount">{currency(balances.ahorros)}</strong></article>
                <article className="account-tile"><span className="eyebrow">CUENTA CORRIENTE</span><strong className="account-amount">{currency(balances.corriente)}</strong></article>
              </div>
              <form className="form-panel" onSubmit={handleAccountOperation}>
                <h2>Nueva operación</h2>
                <div className="field-row">
                  <label className="field"><span>Tipo de operación</span><select name="operacion" defaultValue={operationPreset.operation}><option value="consignar">Consignar</option><option value="retirar">Retirar</option></select></label>
                  <label className="field"><span>Cuenta</span><select name="cuenta" defaultValue={operationPreset.account}><option value="ahorros">Cuenta de ahorros</option><option value="corriente">Cuenta corriente</option></select></label>
                </div>
                <label className="field"><span>Monto (COP)</span><input name="monto" type="number" min="1" step="any" placeholder="Ej. 50000" required /></label>
                <button className="button" type="submit">Continuar operación <span>→</span></button>
              </form>
            </section>
          )}

          {section === 'transferir' && (
            <section className="dashboard-section">
              <div className="section-intro"><h2>Envía dinero fácilmente</h2><p>Transfiere entre tus cuentas o a otro cliente Kapitalia.</p></div>
              <form className="form-panel" onSubmit={handleTransfer}>
                <div className="transfer-route"><span className="route-icon">⇄</span><span>Transferencia segura entre cuentas Kapitalia</span></div>
                <div className="field-row">
                  <label className="field"><span>Cuenta de origen</span><select name="origen"><option value="ahorros">Cuenta de ahorros</option><option value="corriente">Cuenta corriente</option></select></label>
                  <label className="field"><span>Destino</span><select name="destino" value={destination} onChange={(event) => setDestination(event.target.value)}><option value="ahorros">Mi cuenta de ahorros</option><option value="corriente">Mi cuenta corriente</option><option value="otro">Otro cliente</option></select></label>
                </div>
                {destination === 'otro' && <label className="field"><span>Usuario destino</span><input name="usuarioDestino" placeholder="Nombre de usuario" required /></label>}
                <label className="field"><span>Monto (COP)</span><input name="monto" type="number" min="1" step="any" placeholder="Ej. 50000" required /></label>
                <button className="button" type="submit">Transferir dinero <span>→</span></button>
              </form>
            </section>
          )}

          {section === 'tarjeta' && (
            <section className="dashboard-section card-section">
              <div className="credit-card-visual">
                <div className="credit-top"><span className="card-chip" /><span>Kapitalia</span></div>
                <div className="credit-number">•••• &nbsp;•••• &nbsp;•••• &nbsp;4829</div>
                <div className="credit-bottom"><span>{user.nombreCompleto.toUpperCase()}</span><strong>VISA</strong></div>
              </div>
              <div className="credit-metrics">
                <div><span>Cupo total</span><strong>{currency(card.cupoTotal)}</strong></div>
                <div><span>Cupo disponible</span><strong>{currency(card.cupoDisponible)}</strong></div>
                <div><span>Deuda actual</span><strong>{currency(card.deuda)}</strong></div>
              </div>
              <div className="account-grid">
                <form className="form-panel" onSubmit={handlePurchase}>
                  <h2>Realizar una compra</h2>
                  <label className="field"><span>Monto (COP)</span><input name="compra" type="number" min="1" step="any" placeholder="Ej. 100000" required /></label>
                  <label className="field"><span>Número de cuotas</span><select name="cuotas">{Array.from({ length: 12 }, (_, index) => <option value={index + 1} key={index + 1}>{index + 1} {index === 0 ? 'cuota' : 'cuotas'}{index < 2 ? ' · 0% interés' : index < 6 ? ' · 1,9% mensual' : ' · 2,3% mensual'}</option>)}</select></label>
                  <button className="button" type="submit">Registrar compra <span>→</span></button>
                </form>
                <form className="form-panel" onSubmit={handlePayment}>
                  <h2>Pagar tarjeta</h2>
                  <p>Abona a tu deuda actual de {currency(card.deuda)}.</p>
                  <label className="field"><span>Monto del pago (COP)</span><input name="pago" type="number" min="1" step="any" placeholder="Ej. 50000" required /></label>
                  <button className="button button-dark" type="submit">Pagar deuda <span>→</span></button>
                </form>
              </div>
              <div className="recent-panel"><div className="panel-heading"><div><span className="eyebrow">COMPRAS</span><h2>Historial de tarjeta</h2></div></div><PurchaseList purchases={card.compras} /></div>
            </section>
          )}

          {section === 'movimientos' && (
            <section className="dashboard-section recent-panel movement-panel">
              <div className="panel-heading"><div><span className="eyebrow">TU ACTIVIDAD</span><h2>Historial de movimientos</h2></div><label className="filter-field"><span>Filtrar</span><select value={filter} onChange={(event) => setFilter(event.target.value)}><option value="todos">Todas las cuentas</option><option value="ahorros">Ahorros</option><option value="corriente">Corriente</option></select></label></div>
              <MovementList movements={movements} />
            </section>
          )}

          {section === 'perfil' && (
            <section className="dashboard-section profile-grid">
              <form className="form-panel" onSubmit={handleProfile}>
                <span className="eyebrow">INFORMACIÓN PERSONAL</span><h2>Mi perfil</h2>
                <label className="field"><span>Nombre completo</span><input name="nombreCompleto" defaultValue={user.nombreCompleto} required /></label>
                <label className="field"><span>Celular</span><input name="celular" type="tel" defaultValue={user.celular} required /></label>
                <label className="field"><span>Usuario</span><input value={user.usuario} readOnly /></label>
                <button className="button" type="submit">Guardar cambios <span>→</span></button>
              </form>
              <form className="form-panel" onSubmit={handlePassword}>
                <span className="eyebrow">SEGURIDAD</span><h2>Cambiar contraseña</h2>
                <label className="field"><span>Contraseña actual</span><input name="actual" type="password" autoComplete="current-password" required /></label>
                <label className="field"><span>Nueva contraseña</span><input name="nueva" type="password" autoComplete="new-password" minLength={4} required /></label>
                <label className="field"><span>Confirmar contraseña</span><input name="confirmar" type="password" autoComplete="new-password" minLength={4} required /></label>
                <button className="button button-dark" type="submit">Actualizar contraseña <span>→</span></button>
              </form>
            </section>
          )}
        </main>
      </div>
      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}

function MovementList({ movements }) {
  if (movements.length === 0) {
    return <div className="empty-state"><span>◷</span><strong>Aún no hay movimientos</strong><p>Cuando realices una operación, aparecerá aquí.</p></div>;
  }
  return (
    <div className="movement-list">
      {movements.map((movement, index) => (
        <div className="movement-row" key={`${movement.fecha}-${movement.tipo}-${index}`}>
          <span className="movement-symbol">{movement.tipo.toLowerCase().includes('consign') ? '↓' : movement.tipo.toLowerCase().includes('transfer') ? '⇄' : '↑'}</span>
          <div className="movement-description"><strong>{movement.tipo}</strong><span>{movement.fecha}{movement.cuenta ? ` · ${movement.cuenta}` : ''}</span></div>
          <strong className="movement-value">{currency(movement.valor)}</strong>
        </div>
      ))}
    </div>
  );
}

function PurchaseList({ purchases }) {
  if (!purchases.length) {
    return <div className="empty-state"><span>▣</span><strong>Aún no hay compras</strong><p>Las compras que realices con tu tarjeta aparecerán aquí.</p></div>;
  }
  return (
    <div className="purchase-list">
      {purchases.map((purchase, index) => (
        <article className="purchase-row" key={`${purchase.fecha}-${index}`}>
          <div><strong>{currency(purchase.monto)}</strong><span>{purchase.fecha} · {purchase.cuotas} cuotas · {purchase.tasa}</span></div>
          <div><span>Cuota mensual</span><strong>{currency(purchase.cuotaMensual)}</strong></div>
          <div><span>Total a pagar</span><strong>{currency(purchase.totalDeuda)}</strong></div>
        </article>
      ))}
    </div>
  );
}

export default DashboardPage;
