import { useState } from 'react';
import { Link } from 'react-router-dom';
import Brand from '../components/Brand.jsx';
import Toast from '../components/Toast.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { AuthService } from '../services/bank.js';

const emptyForm = {
  identificacion: '',
  nombreCompleto: '',
  celular: '',
  usuario: '',
  contrasena: '',
};

export default function AdminPage() {
  const { user, logout, updateProfile } = useAuth();
  const [customers, setCustomers] = useState(() => new AuthService().getAllClientes());
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');
  const [toast, setToast] = useState(null);

  function notify(message, type = 'success') {
    setToast({ message, type });
    window.setTimeout(() => setToast(null), 4500);
  }

  function openCreateForm() {
    setEditingCustomer(null);
    setForm(emptyForm);
    setError('');
    setIsFormOpen(true);
  }

  function openEditForm(customer) {
    setEditingCustomer(customer);
    setForm({
      identificacion: customer.identificacion,
      nombreCompleto: customer.nombreCompleto,
      celular: customer.celular || '',
      usuario: customer.usuario,
      contrasena: '',
    });
    setError('');
    setIsFormOpen(true);
  }

  function closeForm() {
    setEditingCustomer(null);
    setError('');
    setIsFormOpen(false);
  }

  function updateField(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    setError('');

    const datos = {
      identificacion: form.identificacion.trim(),
      nombreCompleto: form.nombreCompleto.trim(),
      celular: form.celular.trim(),
      usuario: form.usuario.trim(),
      contrasena: form.contrasena,
    };

    if (!datos.identificacion || !datos.nombreCompleto || !datos.celular || !datos.usuario) {
      setError('Completa todos los campos obligatorios.');
      return;
    }

    const service = new AuthService();
    try {
      if (editingCustomer) {
        if (datos.contrasena && datos.contrasena.length < 4) {
          setError('La contraseña debe tener al menos 4 caracteres.');
          return;
        }
        const changes = {
          nombreCompleto: datos.nombreCompleto,
          celular: datos.celular,
        };
        if (datos.contrasena) changes.contrasena = datos.contrasena;
        service.editar(editingCustomer.id, changes);
        if (editingCustomer.id === user.id) updateProfile(changes);
        notify(`Se actualizaron los datos de ${datos.nombreCompleto}.`);
      } else {
        if (datos.contrasena.length < 4) {
          setError('La contraseña debe tener al menos 4 caracteres.');
          return;
        }
        service.registrar(datos);
        notify(`Se creó la cuenta de ${datos.nombreCompleto}.`);
      }

      setCustomers(service.getAllClientes());
      closeForm();
    } catch (saveError) {
      setError(saveError.message || 'No se pudo guardar el usuario.');
    }
  }

  function deleteCustomer(customer) {
    if (customer.id === user.id) {
      notify('No puedes eliminar tu propia cuenta mientras tienes la sesión activa.', 'error');
      return;
    }
    if (!window.confirm(`¿Eliminar la cuenta de ${customer.nombreCompleto}? Esta acción no se puede deshacer.`)) return;

    try {
      const service = new AuthService();
      service.eliminar(customer.id);
      setCustomers(service.getAllClientes());
      notify(`Se eliminó la cuenta de ${customer.nombreCompleto}.`);
    } catch (deleteError) {
      notify(deleteError.message || 'No se pudo eliminar el usuario.', 'error');
    }
  }

  return (
    <div className="dashboard-shell">
      <header className="dashboard-topbar">
        <Brand />
        <div className="topbar-actions">
          <Link className="button button-outline button-small" to="/dashboard">Volver a mi cuenta</Link>
          <button className="button button-outline button-small" type="button" onClick={logout}>Cerrar sesión</button>
        </div>
      </header>

      <main className="admin-content">
        <div className="admin-heading">
          <div>
            <span className="eyebrow">GESTIÓN DE CLIENTES</span>
            <h1>Administración de usuarios</h1>
            <p>Consulta las cuentas registradas y actualiza sus datos.</p>
          </div>
          <button className="button" type="button" onClick={openCreateForm}>＋ Agregar usuario</button>
        </div>

        <section className="admin-table-card" aria-label="Usuarios registrados">
          <div className="admin-table-heading">
            <div><h2>Clientes</h2><span>{customers.length} {customers.length === 1 ? 'cuenta registrada' : 'cuentas registradas'}</span></div>
            <span className="admin-table-count">Kapitalia</span>
          </div>
          <div className="admin-table-scroll">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre completo</th>
                  <th>Usuario</th>
                  <th>Celular</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((customer) => (
                  <tr key={customer.id}>
                    <td className="admin-id">{customer.id}</td>
                    <td><strong className="admin-customer-name">{customer.nombreCompleto}</strong><span className="admin-identification">ID {customer.identificacion}</span></td>
                    <td>@{customer.usuario}</td>
                    <td>{customer.celular || '—'}</td>
                    <td><span className={`customer-status${customer.bloqueado ? ' customer-locked' : ''}`}><span />{customer.bloqueado ? 'Bloqueada' : 'Activa'}</span></td>
                    <td>
                      <div className="admin-row-actions">
                        <button type="button" onClick={() => openEditForm(customer)} aria-label={`Editar a ${customer.nombreCompleto}`}>Editar</button>
                        <button
                          className="delete-action"
                          type="button"
                          disabled={customer.id === user.id}
                          onClick={() => deleteCustomer(customer)}
                          aria-label={`Eliminar a ${customer.nombreCompleto}`}
                          title={customer.id === user.id ? 'No puedes eliminar tu propia cuenta' : `Eliminar a ${customer.nombreCompleto}`}
                        >
                          Eliminar
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {customers.length === 0 && (
                  <tr><td className="admin-empty" colSpan={6}>Todavía no hay usuarios registrados.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <p className="admin-data-note">Los datos se almacenan localmente en este navegador.</p>
        </section>
      </main>

      {isFormOpen && (
        <div className="admin-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) closeForm(); }}>
          <section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="admin-form-title">
            <div className="admin-modal-heading">
              <div>
                <span className="eyebrow">{editingCustomer ? 'DATOS DE LA CUENTA' : 'NUEVA CUENTA'}</span>
                <h2 id="admin-form-title">{editingCustomer ? 'Editar usuario' : 'Agregar usuario'}</h2>
              </div>
              <button className="modal-dismiss" type="button" onClick={closeForm} aria-label="Cerrar formulario">×</button>
            </div>
            <form onSubmit={handleSubmit}>
              <label className="field">
                <span>Identificación</span>
                <input name="identificacion" value={form.identificacion} onChange={updateField} readOnly={Boolean(editingCustomer)} required />
              </label>
              <label className="field">
                <span>Nombre completo</span>
                <input name="nombreCompleto" value={form.nombreCompleto} onChange={updateField} autoComplete="name" required />
              </label>
              <label className="field">
                <span>Celular</span>
                <input name="celular" type="tel" value={form.celular} onChange={updateField} autoComplete="tel" required />
              </label>
              <label className="field">
                <span>Usuario</span>
                <input name="usuario" value={form.usuario} onChange={updateField} readOnly={Boolean(editingCustomer)} autoComplete="username" required />
              </label>
              <label className="field">
                <span>Contraseña {editingCustomer && <span className="optional-label">(dejar en blanco para conservarla)</span>}</span>
                <input name="contrasena" type="password" value={form.contrasena} onChange={updateField} autoComplete="new-password" minLength={4} required={!editingCustomer} />
              </label>
              {error && <p className="form-message form-error" role="alert">{error}</p>}
              <div className="admin-modal-actions">
                <button className="button button-outline" type="button" onClick={closeForm}>Cancelar</button>
                <button className="button" type="submit">{editingCustomer ? 'Guardar cambios' : 'Crear usuario'}</button>
              </div>
            </form>
          </section>
        </div>
      )}
      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}
