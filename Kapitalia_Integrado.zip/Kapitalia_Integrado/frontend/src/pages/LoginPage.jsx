import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Brand from '../components/Brand.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(3);

  function handleSubmit(event) {
    event.preventDefault();
    setError('');
    const form = new FormData(event.currentTarget);
    try {
      login(form.get('usuario'), form.get('contrasena'));
      navigate(location.state?.from?.pathname || '/dashboard', { replace: true });
    } catch (loginError) {
      setError(loginError.message);
      const remaining = loginError.message.match(/Intentos restantes: (\d+)/);
      if (remaining) setAttempts(Number(remaining[1]));
      if (loginError.message.includes('bloqueada')) setAttempts(0);
    }
  }

  return (
    <main className="auth-layout">
      <aside className="auth-aside">
        <Brand light />
        <div className="auth-aside-copy">
          <span className="eyebrow">BIENVENIDO DE NUEVO</span>
          <h1>Tu dinero, en buenas manos.</h1>
          <p>Accede a tus cuentas y sigue avanzando con Kapitalia.</p>
        </div>
        <span className="auth-aside-foot">Banca digital pensada para ti.</span>
      </aside>
      <section className="auth-panel">
        <div className="auth-mobile-brand"><Brand /></div>
        <div className="auth-card">
          <span className="eyebrow">ACCESO A CLIENTES</span>
          <h2>Inicia sesión</h2>
          <p className="auth-subtitle">Ingresa tus datos para continuar a tu cuenta.</p>
          <form onSubmit={handleSubmit}>
            <label className="field">
              <span>Usuario</span>
              <input name="usuario" type="text" autoComplete="username" placeholder="Tu nombre de usuario" required />
            </label>
            <label className="field">
              <span>Contraseña</span>
              <input name="contrasena" type="password" autoComplete="current-password" placeholder="Ingresa tu contraseña" required />
            </label>
            <p className="attempts-note">Intentos disponibles: <strong>{attempts}</strong></p>
            {error && <div className="form-message form-error" role="alert">{error}</div>}
            <button className="button button-full" type="submit" disabled={attempts === 0}>Ingresar a mi cuenta <span>→</span></button>
          </form>
          <p className="auth-switch">¿Aún no tienes una cuenta? <Link to="/registro">Regístrate aquí</Link></p>
          <p className="demo-hint">Demo: usuario <strong>demo</strong> · contraseña <strong>1234</strong></p>
        </div>
        <Link className="back-home" to="/">← Volver al inicio</Link>
      </section>
    </main>
  );
}
