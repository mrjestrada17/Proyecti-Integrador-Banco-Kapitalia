import { Link } from 'react-router-dom';

export default function Brand({ light = false }) {
  return (
    <Link className={`brand${light ? ' brand-light' : ''}`} to="/" aria-label="Kapitalia, inicio">
      <img src="/logo.png" alt="" />
      <span>Kapitalia</span>
    </Link>
  );
}
