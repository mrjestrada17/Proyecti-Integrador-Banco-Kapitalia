export default function Toast({ toast, onClose }) {
  if (!toast) return null;

  return (
    <div className={`toast toast-${toast.type}`} role="status" onClick={onClose}>
      <span>{toast.message}</span>
      <button type="button" aria-label="Cerrar aviso" onClick={onClose}>×</button>
    </div>
  );
}
