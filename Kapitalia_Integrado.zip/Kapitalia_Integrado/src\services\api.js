/**
 * Cliente de conexión con el Backend Spring Boot de Sistema Bancario ATM
 * Endpoints base: http://localhost:8080/api
 */
export const API_BASE_URL = (typeof window !== 'undefined' && window.__KAPITALIA_API_URL__)
    || (typeof import.meta !== 'undefined' && import.meta.env?.VITE_API_URL)
    || 'http://localhost:8080/api';

class ApiService {
    constructor(baseUrl = API_BASE_URL) {
        this.baseUrl = baseUrl;
        this.isOnline = null;
    }

    /**
     * Verifica la disponibilidad del Backend Spring Boot
     */
    async checkHealth() {
        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 2500);
            const res = await fetch(`${this.baseUrl}/tipos-operacion`, {
                signal: controller.signal,
                headers: { 'Accept': 'application/json' }
            });
            clearTimeout(timeout);
            this.isOnline = res.ok;
            return res.ok;
        } catch {
            this.isOnline = false;
            return false;
        }
    }

    // ==========================================
    // CUENTAS
    // ==========================================

    async getCuentas() {
        const res = await fetch(`${this.baseUrl}/cuentas`);
        if (!res.ok) throw new Error(`Error ${res.status}: No se pudieron cargar las cuentas.`);
        return res.json();
    }

    async getCuenta(id) {
        const res = await fetch(`${this.baseUrl}/cuentas/${id}`);
        if (!res.ok) throw new Error(`Error ${res.status}: Cuenta no encontrada con ID ${id}`);
        return res.json();
    }

    async getCuentaPorNumero(numeroCuenta) {
        const res = await fetch(`${this.baseUrl}/cuentas/numero/${encodeURIComponent(numeroCuenta)}`);
        if (!res.ok) throw new Error(`No se encontró la cuenta: ${numeroCuenta}`);
        return res.json();
    }

    async crearCuenta({ numeroCuenta, tipoCuenta, saldoDisponible = 0, estado = 'Activa' }) {
        const res = await fetch(`${this.baseUrl}/cuentas`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ numeroCuenta, tipoCuenta, saldoDisponible, estado })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.mensaje || 'Error al registrar la cuenta bancaria.');
        }
        return res.json();
    }

    // ==========================================
    // TARJETAS
    // ==========================================

    async getTarjetas() {
        const res = await fetch(`${this.baseUrl}/tarjetas`);
        if (!res.ok) throw new Error(`Error ${res.status}: No se pudieron listar las tarjetas.`);
        return res.json();
    }

    async getTarjetasPorCuenta(idCuenta) {
        const res = await fetch(`${this.baseUrl}/tarjetas/cuenta/${idCuenta}`);
        if (!res.ok) throw new Error(`Error ${res.status}: Tarjetas no encontradas.`);
        return res.json();
    }

    async crearTarjeta({ idCuenta, numeroTarjeta, tipoTarjeta, cupoAvance = null, fechaVencimiento }) {
        const res = await fetch(`${this.baseUrl}/tarjetas`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idCuenta, numeroTarjeta, tipoTarjeta, cupoAvance, fechaVencimiento })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.mensaje || 'Error al registrar la tarjeta.');
        }
        return res.json();
    }

    // ==========================================
    // TIPOS DE OPERACIÓN
    // ==========================================

    async getTiposOperacion() {
        const res = await fetch(`${this.baseUrl}/tipos-operacion`);
        if (!res.ok) throw new Error('Error al listar tipos de operación.');
        return res.json();
    }

    // ==========================================
    // TRANSACCIONES (Consignación, Retiro, Transferencia, Pago Tarjeta, Avance)
    // ==========================================

    /**
     * Procesa una transacción oficial a través de la API Spring Boot
     * @param {Object} datos
     * @param {number} datos.idTarjeta
     * @param {number} datos.idTipoOperacion (1: Consignación, 2: Retiro, 3: Transf. Enviada, 5: Pago Tarjeta, 6: Avance)
     * @param {number} datos.idCuentaOrigen
     * @param {number|null} [datos.idCuentaDestino]
     * @param {number} datos.monto
     * @param {string} [datos.codigoCajero]
     */
    async procesarTransaccion({ idTarjeta, idTipoOperacion, idCuentaOrigen, idCuentaDestino = null, monto, codigoCajero = 'ATM-KAP01' }) {
        const res = await fetch(`${this.baseUrl}/transacciones`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                idTarjeta,
                idTipoOperacion,
                idCuentaOrigen,
                idCuentaDestino,
                monto: Number(monto),
                codigoCajero
            })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.mensaje || `Error al procesar la transacción (${res.status})`);
        }
        return res.json();
    }

    async getTransaccionesPorCuenta(idCuenta) {
        const res = await fetch(`${this.baseUrl}/transacciones/cuenta/${idCuenta}`);
        if (!res.ok) throw new Error(`Error al consultar transacciones de cuenta ${idCuenta}`);
        return res.json();
    }

    async getTransaccionesPorTarjeta(idTarjeta) {
        const res = await fetch(`${this.baseUrl}/transacciones/tarjeta/${idTarjeta}`);
        if (!res.ok) throw new Error(`Error al consultar transacciones de tarjeta ${idTarjeta}`);
        return res.json();
    }

    async getUltimasTransacciones() {
        const res = await fetch(`${this.baseUrl}/transacciones`);
        if (!res.ok) throw new Error('Error al listar transacciones globales.');
        return res.json();
    }
}

export const api = new ApiService();
export default api;
