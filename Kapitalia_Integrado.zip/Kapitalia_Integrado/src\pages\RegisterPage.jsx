import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Brand from '../components/Brand.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    setError('');
    const form = new FormData(event.currentTarget);
    const identificacion = form.get('identificacion').trim();
    const nombreCompleto = form.get('nombreCompleto').trim();
    const celular = form.get('celular').trim();
    const usuario = form.get('usuario').trim();
    const contrasena = form.get('contrasena');

    if (contrasena.length < 4) {
      setError('La contraseña debe tener al menos 4 caracteres.');
      return;
    }
    if (contrasena !== form.get('confirmarContrasena')) {
      setError('Las contraseñas no coinciden.');
      return;
    }

    try {
      register({ identificacion, nombreCompleto, celular, usuario, contrasena });
      navigate('/login', { replace: true, state: { registered: true } });
    } catch (registrationError) {
      setError(registrationError.message);
    }
  }

  return (
    <main className="auth-layout">
      <aside className="auth-aside">
        <Brand light />
        <div className="auth-aside-copy">
          <span className="eyebrow">UN GRAN PASO</span>
          <h1>Empieza a construir tus metas.</h1>
          <p>Abre tu cuenta Kapitalia y ten tus finanzas siempre a la mano.</p>
        </div>
        <span className="auth-aside-foot">Tu siguiente paso empieza aquí.</span>
      </aside>
      <section className="auth-panel">
        <div className="auth-mobile-brand"><Brand /></div>
        <div className="auth-card register-card">
          <span className="eyebrow">NUEVO CLIENTE</span>
          <h2>Crea tu cuenta</h2>
          <p className="auth-subtitle">Completa tus datos para comenzar.</p>
          <form onSubmit={handleSubmit}>
            <label className="field">
              <span>Identificación</span>
              <input name="identificacion" autoComplete="off" required />
            </label>
            <label className="field">
              <span>Nombre completo</span>
              <input name="nombreCompleto" autoComplete="name" required />
            </label>
            <label className="field">
              <span>Celular</span>
              <input name="celular" type="tel" autoComplete="tel" required />
            </label>
            <label className="field">
              <span>Usuario</span>
              <input name="usuario" autoComplete="username" required />
            </label>
            <div className="field-row">
              <label className="field">
                <span>Contraseña</span>
                <input name="contrasena" type="password" autoComplete="new-password" minLength={4} required />
              </label>
              <label className="field">
                <span>Confirmar contraseña</span>
                <input name="confirmarContrasena" type="password" autoComplete="new-password" minLength={4} required />
              </label>
            </div>
            {error && <div className="form-message form-error" role="alert">{error}</div>}
            <button className="button button-full" type="submit">Crear cuenta <span>→</span></button>
          </form>
          <p className="auth-switch">¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link></p>
        </div>
        <Link className="back-home" to="/">← Volver al inicio</Link>
      </section>
    </main>
  );
}
