# Kapitalia - Backend Java + MySQL (XAMPP)

Backend REST desarrollado con Java 17, Spring Boot, Spring Data JPA y MySQL.

## 1. Requisitos
- Java JDK 17.
- IntelliJ IDEA (o IDE compatible con Maven).
- XAMPP con MySQL/MariaDB iniciado.

## 2. Crear la base de datos
1. Abre XAMPP y pulsa **Start** en MySQL.
2. Entra a `http://localhost/phpmyadmin`.
3. Selecciona **Importar** y carga `database/crear_base_datos.sql`.
4. Pulsa **Continuar**. Debe quedar creada la base de datos `kapitalia`.

Las tablas `cuenta`, `tarjeta`, `tipo_operacion` y `transaccion` se crean/actualizan automáticamente al iniciar el backend. No se borran al reiniciar.

> Configuración predeterminada de XAMPP: usuario `root` y contraseña vacía. Si configuraste otra contraseña, establece `DB_PASSWORD` en las variables de entorno de la ejecución de IntelliJ. También puedes cambiar `DB_USER` y `DB_URL`.

## 3. Ejecutar el backend
1. Abre en IntelliJ la carpeta que contiene `pom.xml`.
2. Espera a que Maven descargue las dependencias.
3. Verifica que el proyecto use JDK 17.
4. Ejecuta `src/main/java/com/banco/atm/SistemaBancarioApplication.java`.
5. En la consola debe aparecer que Spring Boot inició en el puerto `8080` sin errores de conexión.

La primera ejecución crea las tablas y registra los seis tipos de operación. No se crean cuentas ni tarjetas de ejemplo: puedes registrarlas desde tu frontend o Swagger.

## 4. Probar la API
- Swagger: `http://localhost:8080/swagger-ui.html`
- Cuentas: `GET http://localhost:8080/api/cuentas`
- Tarjetas: `GET http://localhost:8080/api/tarjetas`
- Tipos: `GET http://localhost:8080/api/tipos-operacion`
- Transacciones: `GET http://localhost:8080/api/transacciones`

### Crear una cuenta (POST /api/cuentas)
```json
{
  "numeroCuenta": "1001001001001001",
  "tipoCuenta": "Ahorros",
  "saldoDisponible": 250000,
  "estado": "Activa"
}
```

### Crear una tarjeta (POST /api/tarjetas)
Usa un `idCuenta` que ya exista. El número debe tener 16 dígitos sin guiones.
```json
{
  "idCuenta": 1,
  "numeroTarjeta": "4532111122223333",
  "tipoTarjeta": "Debito",
  "cupoAvance": null,
  "fechaVencimiento": "2028-12-31"
}
```

### Registrar una transacción (POST /api/transacciones)
Usa IDs reales obtenidos de las consultas anteriores. `idTipoOperacion` corresponde al catálogo que devuelve `/api/tipos-operacion`.
```json
{
  "idTarjeta": 1,
  "idTipoOperacion": 2,
  "idCuentaOrigen": 1,
  "idCuentaDestino": null,
  "monto": 200.00,
  "codigoCajero": "ATM-001"
}
```

## 5. Conectar el frontend
Desde JavaScript, llama a la API en `http://localhost:8080`. Ejemplo:
```javascript
fetch('http://localhost:8080/api/cuentas')
  .then(respuesta => {
    if (!respuesta.ok) throw new Error('No se pudieron consultar las cuentas');
    return respuesta.json();
  })
  .then(cuentas => console.log(cuentas))
  .catch(error => console.error(error));
```

Para guardar una cuenta, utiliza `fetch` con método `POST`, `Content-Type: application/json` y el objeto JSON indicado arriba.

**Importante:** este ZIP contiene únicamente el backend. Para conectar los botones, formularios y pantallas exactas de tu página necesito también el proyecto/carpeta del frontend. Con este backend ya quedan disponibles los endpoints para guardar y consultar cuentas, tarjetas y transacciones.

## 6. Notas
- Los datos se guardan en MySQL, no en una base H2 en memoria.
- No elimines la base de datos desde phpMyAdmin si quieres conservar los registros.
- El proyecto permite CORS para facilitar el desarrollo local. En producción se debe restringir a la URL real del frontend.
