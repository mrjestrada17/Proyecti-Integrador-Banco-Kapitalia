package com.banco.atm.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransaccionRequestDTO {

    @NotNull(message = "El ID de tarjeta es requerido")
    private Long idTarjeta;

    @NotNull(message = "El ID de tipo de operación es requerido")
    private Long idTipoOperacion;

    @NotNull(message = "El ID de cuenta de origen es requerido")
    private Long idCuentaOrigen;

    private Long idCuentaDestino; // NULLABLE

    @NotNull(message = "El monto es requerido")
    @Positive(message = "El monto debe ser estrictamente mayor a 0")
    private BigDecimal monto;

    @NotNull(message = "El código del cajero es requerido")
    @Size(max = 10, message = "El código del cajero no puede exceder los 10 caracteres")
    private String codigoCajero;
}
