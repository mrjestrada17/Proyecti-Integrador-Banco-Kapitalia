package com.banco.atm.service.impl;

import com.banco.atm.dto.CuentaDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.CuentaMapper;
import com.banco.atm.model.Cuenta;
import com.banco.atm.repository.CuentaRepository;
import com.banco.atm.service.CuentaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CuentaServiceImpl implements CuentaService {

    private final CuentaRepository cuentaRepository;
    private final CuentaMapper cuentaMapper;

    @Override
    @Transactional(readOnly = true)
    public List<CuentaDTO> listarCuentas() {
        return cuentaRepository.findAll().stream()
                .map(cuentaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CuentaDTO obtenerCuentaPorId(Long idCuenta) {
        Cuenta cuenta = buscarEntidadPorId(idCuenta);
        return cuentaMapper.toDTO(cuenta);
    }

    @Override
    @Transactional(readOnly = true)
    public CuentaDTO obtenerCuentaPorNumero(String numeroCuenta) {
        Cuenta cuenta = cuentaRepository.findByNumeroCuenta(numeroCuenta)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta bancaria no encontrada con número: " + numeroCuenta));
        return cuentaMapper.toDTO(cuenta);
    }

    @Override
    @Transactional
    public CuentaDTO crearCuenta(CuentaDTO dto) {
        if (cuentaRepository.existsByNumeroCuenta(dto.getNumeroCuenta())) {
            throw new BusinessException("Ya existe una cuenta con el número: " + dto.getNumeroCuenta());
        }
        Cuenta cuenta = cuentaMapper.toEntity(dto);
        if (cuenta.getSaldoDisponible() == null) {
            cuenta.setSaldoDisponible(BigDecimal.ZERO);
        }
        if (cuenta.getEstado() == null) {
            cuenta.setEstado("Activa");
        }
        Cuenta guardada = cuentaRepository.save(cuenta);
        return cuentaMapper.toDTO(guardada);
    }

    @Override
    @Transactional
    public CuentaDTO actualizarSaldo(Long idCuenta, BigDecimal nuevoSaldo) {
        if (nuevoSaldo == null || nuevoSaldo.compareTo(BigDecimal.ZERO) < 0) {
            throw new BusinessException("El saldo no puede ser negativo.");
        }
        Cuenta cuenta = buscarEntidadParaActualizar(idCuenta);
        cuenta.setSaldoDisponible(nuevoSaldo);
        Cuenta actualizada = cuentaRepository.save(cuenta);
        return cuentaMapper.toDTO(actualizada);
    }

    @Override
    @Transactional
    public CuentaDTO cambiarEstado(Long idCuenta, String nuevoEstado) {
        if (!"Activa".equalsIgnoreCase(nuevoEstado) && !"Bloqueada".equalsIgnoreCase(nuevoEstado)) {
            throw new BusinessException("Estado inválido. Debe ser 'Activa' o 'Bloqueada'.");
        }
        Cuenta cuenta = buscarEntidadParaActualizar(idCuenta);
        cuenta.setEstado(nuevoEstado);
        Cuenta actualizada = cuentaRepository.save(cuenta);
        return cuentaMapper.toDTO(actualizada);
    }

    @Override
    @Transactional(readOnly = true)
    public Cuenta buscarEntidadPorId(Long idCuenta) {
        return cuentaRepository.findById(idCuenta)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta no encontrada con ID: " + idCuenta));
    }

    @Override
    @Transactional
    public Cuenta buscarEntidadParaActualizar(Long idCuenta) {
        return cuentaRepository.findByIdForUpdate(idCuenta)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta no encontrada con ID: " + idCuenta));
    }
}
