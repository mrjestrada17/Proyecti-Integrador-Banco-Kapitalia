package com.banco.atm.model.enums;

import lombok.Getter;

@Getter
public enum EstadoCuenta {
    ACTIVA("Activa"),
    BLOQUEADA("Bloqueada");

    private final String descripcion;

    EstadoCuenta(String descripcion) {
        this.descripcion = descripcion;
    }

    public static EstadoCuenta fromString(String valor) {
        for (EstadoCuenta estado : values()) {
            if (estado.descripcion.equalsIgnoreCase(valor) || estado.name().equalsIgnoreCase(valor)) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Estado de cuenta no válido: " + valor);
    }
}
