package com.banco.atm.exception;

public class SaldoInsuficienteException extends BusinessException {
    public SaldoInsuficienteException(String message) {
        super(message);
    }
}
