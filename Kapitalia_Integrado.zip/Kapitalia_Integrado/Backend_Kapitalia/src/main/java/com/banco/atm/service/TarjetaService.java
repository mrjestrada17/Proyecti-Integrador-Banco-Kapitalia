package com.banco.atm.service;

import com.banco.atm.dto.TarjetaDTO;
import com.banco.atm.model.Tarjeta;

import java.util.List;

public interface TarjetaService {
    List<TarjetaDTO> listarTarjetas();
    TarjetaDTO obtenerTarjetaPorId(Long idTarjeta);
    TarjetaDTO obtenerTarjetaPorNumero(String numeroTarjeta);
    List<TarjetaDTO> listarPorCuenta(Long idCuenta);
    TarjetaDTO crearTarjeta(TarjetaDTO dto);
    Tarjeta buscarEntidadPorId(Long idTarjeta);
    Tarjeta buscarEntidadParaActualizar(Long idTarjeta);
    void validarTarjetaParaOperar(Tarjeta tarjeta, Long idCuentaOrigen);
}
