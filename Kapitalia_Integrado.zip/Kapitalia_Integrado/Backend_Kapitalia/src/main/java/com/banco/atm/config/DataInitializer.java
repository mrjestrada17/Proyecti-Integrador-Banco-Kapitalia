package com.banco.atm.config;

import com.banco.atm.model.TipoOperacion;
import com.banco.atm.model.enums.OperacionEnum;
import com.banco.atm.repository.TipoOperacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final TipoOperacionRepository tipoOperacionRepository;

    @Override
    public void run(String... args) {
        // Crea los seis tipos oficiales solo si no existen.
        for (OperacionEnum operacion : OperacionEnum.values()) {
            if (!tipoOperacionRepository.existsByNombreOperacion(operacion.getNombre())) {
                tipoOperacionRepository.save(TipoOperacion.builder()
                        .nombreOperacion(operacion.getNombre())
                        .requiereDestino(operacion.isRequiereDestino())
                        .build());
            }
        }
    }
}
