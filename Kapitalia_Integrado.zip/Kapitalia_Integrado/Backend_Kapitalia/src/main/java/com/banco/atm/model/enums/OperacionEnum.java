package com.banco.atm.model.enums;

import lombok.Getter;

@Getter
public enum OperacionEnum {
    CONSIGNACION("Consignación", false),
    RETIRO("Retiro", false),
    TRANSF_ENVIADA("Transf. Enviada", true),
    TRANSF_RECIBIDA("Transf. Recibida", false),
    PAGO_TARJETA("Pago Tarjeta", false),
    AVANCE_EFECTIVO("Avance Efectivo", false);

    private final String nombre;
    private final boolean requiereDestino;

    OperacionEnum(String nombre, boolean requiereDestino) {
        this.nombre = nombre;
        this.requiereDestino = requiereDestino;
    }

    public static OperacionEnum fromNombre(String nombre) {
        if (nombre == null) return null;
        for (OperacionEnum op : values()) {
            if (op.nombre.equalsIgnoreCase(nombre.trim())) {
                return op;
            }
        }
        return null;
    }
}
