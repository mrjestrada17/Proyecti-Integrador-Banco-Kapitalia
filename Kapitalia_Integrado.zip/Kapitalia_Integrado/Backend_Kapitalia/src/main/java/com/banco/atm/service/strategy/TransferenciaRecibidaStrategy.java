package com.banco.atm.service.strategy;

import org.springframework.stereotype.Component;

@Component
public class TransferenciaRecibidaStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Transf. Recibida".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "")
                || "Transferencia Recibida".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        context.getCuentaOrigen().acreditar(context.getMonto());
        context.setMensajeResultado(String.format("Transferencia recibida por $%s en la cuenta %s. Nuevo saldo: $%s",
                context.getMonto(), context.getCuentaOrigen().getNumeroCuenta(), context.getCuentaOrigen().getSaldoDisponible()));
    }
}
