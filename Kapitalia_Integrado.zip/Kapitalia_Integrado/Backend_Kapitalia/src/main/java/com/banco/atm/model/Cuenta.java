package com.banco.atm.model;

import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.CuentaBloqueadaException;
import com.banco.atm.exception.SaldoInsuficienteException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "cuenta")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "tarjetas")
public class Cuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cuenta")
    private Long idCuenta;

    @NotBlank(message = "El número de cuenta es obligatorio")
    @Size(max = 20, message = "El número de cuenta no puede superar los 20 caracteres")
    @Column(name = "numero_cuenta", nullable = false, unique = true, length = 20)
    private String numeroCuenta;

    @NotBlank(message = "El tipo de cuenta es obligatorio")
    @Column(name = "tipo_cuenta", nullable = false, length = 15)
    private String tipoCuenta; // 'Ahorros', 'Corriente'

    @NotNull(message = "El saldo disponible es obligatorio")
    @DecimalMin(value = "0.00", message = "El saldo no puede ser negativo")
    @Column(name = "saldo_disponible", nullable = false, precision = 12, scale = 2)
    @Builder.Default
    private BigDecimal saldoDisponible = BigDecimal.ZERO;

    @NotBlank(message = "El estado de la cuenta es obligatorio")
    @Column(name = "estado", nullable = false, length = 10)
    @Builder.Default
    private String estado = "Activa"; // 'Activa', 'Bloqueada'

    @JsonIgnore
    @OneToMany(mappedBy = "cuenta", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Tarjeta> tarjetas = new ArrayList<>();

    // ==========================================
    // Métodos de Dominio (Rich Domain Model / DDD)
    // ==========================================

    public boolean isActiva() {
        return "Activa".equalsIgnoreCase(this.estado);
    }

    public boolean isBloqueada() {
        return "Bloqueada".equalsIgnoreCase(this.estado);
    }

    /**
     * Debita un monto del saldo disponible validando estado de cuenta y fondos suficientes.
     */
    public void debitar(BigDecimal monto) {
        if (!isActiva()) {
            throw new CuentaBloqueadaException("No es posible debitar: la cuenta " + this.numeroCuenta + " no está Activa (Estado: " + this.estado + ").");
        }
        if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("El monto a debitar debe ser un valor positivo mayor a 0.");
        }
        if (this.saldoDisponible.compareTo(monto) < 0) {
            throw new SaldoInsuficienteException(
                    String.format("Saldo insuficiente en la cuenta %s. Saldo disponible: $%s, Monto solicitado: $%s",
                            this.numeroCuenta, this.saldoDisponible, monto));
        }
        this.saldoDisponible = this.saldoDisponible.subtract(monto);
    }

    /**
     * Acredita un monto al saldo disponible validando el estado de la cuenta.
     */
    public void acreditar(BigDecimal monto) {
        if (!isActiva()) {
            throw new CuentaBloqueadaException("No es posible acreditar: la cuenta " + this.numeroCuenta + " no está Activa (Estado: " + this.estado + ").");
        }
        if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("El monto a acreditar debe ser un valor positivo mayor a 0.");
        }
        this.saldoDisponible = this.saldoDisponible.add(monto);
    }

    public void bloquear() {
        this.estado = "Bloqueada";
    }

    public void activar() {
        this.estado = "Activa";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cuenta cuenta = (Cuenta) o;
        return Objects.equals(idCuenta, cuenta.idCuenta) || Objects.equals(numeroCuenta, cuenta.numeroCuenta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroCuenta != null ? numeroCuenta : idCuenta);
    }
}
