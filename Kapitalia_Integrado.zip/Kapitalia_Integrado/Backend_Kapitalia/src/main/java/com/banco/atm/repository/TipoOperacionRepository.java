package com.banco.atm.repository;

import com.banco.atm.model.TipoOperacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TipoOperacionRepository extends JpaRepository<TipoOperacion, Long> {

    Optional<TipoOperacion> findByNombreOperacion(String nombreOperacion);

    Optional<TipoOperacion> findByNombreOperacionIgnoreCase(String nombreOperacion);

    boolean existsByNombreOperacion(String nombreOperacion);
}
