package com.banco.atm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CuentaDTO {
    private Long idCuenta;
    private String numeroCuenta;
    private String tipoCuenta;
    private BigDecimal saldoDisponible;
    private String estado;
}
