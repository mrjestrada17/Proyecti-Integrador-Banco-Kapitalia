package com.banco.atm.service;

import com.banco.atm.dto.TipoOperacionDTO;
import com.banco.atm.model.TipoOperacion;

import java.util.List;

public interface TipoOperacionService {
    List<TipoOperacionDTO> listarTiposOperacion();
    TipoOperacionDTO obtenerTipoOperacionPorId(Long idTipoOperacion);
    TipoOperacionDTO obtenerPorNombre(String nombreOperacion);
    TipoOperacionDTO crearTipoOperacion(TipoOperacionDTO dto);
    TipoOperacion buscarEntidadPorId(Long idTipoOperacion);
}
