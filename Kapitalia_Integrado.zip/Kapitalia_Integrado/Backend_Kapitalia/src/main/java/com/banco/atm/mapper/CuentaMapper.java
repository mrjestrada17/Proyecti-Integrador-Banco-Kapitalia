package com.banco.atm.mapper;

import com.banco.atm.dto.CuentaDTO;
import com.banco.atm.model.Cuenta;
import org.springframework.stereotype.Component;

@Component
public class CuentaMapper {

    public CuentaDTO toDTO(Cuenta entity) {
        if (entity == null) return null;
        return CuentaDTO.builder()
                .idCuenta(entity.getIdCuenta())
                .numeroCuenta(entity.getNumeroCuenta())
                .tipoCuenta(entity.getTipoCuenta())
                .saldoDisponible(entity.getSaldoDisponible())
                .estado(entity.getEstado())
                .build();
    }

    public Cuenta toEntity(CuentaDTO dto) {
        if (dto == null) return null;
        return Cuenta.builder()
                .idCuenta(dto.getIdCuenta())
                .numeroCuenta(dto.getNumeroCuenta())
                .tipoCuenta(dto.getTipoCuenta())
                .saldoDisponible(dto.getSaldoDisponible())
                .estado(dto.getEstado())
                .build();
    }
}
