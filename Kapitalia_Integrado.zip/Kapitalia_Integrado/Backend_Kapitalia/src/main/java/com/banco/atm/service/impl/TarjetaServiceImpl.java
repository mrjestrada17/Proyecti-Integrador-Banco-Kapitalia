package com.banco.atm.service.impl;

import com.banco.atm.dto.TarjetaDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.TarjetaMapper;
import com.banco.atm.model.Cuenta;
import com.banco.atm.model.Tarjeta;
import com.banco.atm.repository.CuentaRepository;
import com.banco.atm.repository.TarjetaRepository;
import com.banco.atm.service.TarjetaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TarjetaServiceImpl implements TarjetaService {

    private final TarjetaRepository tarjetaRepository;
    private final CuentaRepository cuentaRepository;
    private final TarjetaMapper tarjetaMapper;

    @Override
    @Transactional(readOnly = true)
    public List<TarjetaDTO> listarTarjetas() {
        return tarjetaRepository.findAll().stream()
                .map(tarjetaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TarjetaDTO obtenerTarjetaPorId(Long idTarjeta) {
        Tarjeta tarjeta = buscarEntidadPorId(idTarjeta);
        return tarjetaMapper.toDTO(tarjeta);
    }

    @Override
    @Transactional(readOnly = true)
    public TarjetaDTO obtenerTarjetaPorNumero(String numeroTarjeta) {
        Tarjeta tarjeta = tarjetaRepository.findByNumeroTarjeta(numeroTarjeta)
                .orElseThrow(() -> new ResourceNotFoundException("Tarjeta no encontrada con número: " + numeroTarjeta));
        return tarjetaMapper.toDTO(tarjeta);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TarjetaDTO> listarPorCuenta(Long idCuenta) {
        return tarjetaRepository.findByCuentaIdCuenta(idCuenta).stream()
                .map(tarjetaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public TarjetaDTO crearTarjeta(TarjetaDTO dto) {
        if (tarjetaRepository.existsByNumeroTarjeta(dto.getNumeroTarjeta())) {
            throw new BusinessException("Ya existe una tarjeta con el número: " + dto.getNumeroTarjeta());
        }
        Cuenta cuenta = cuentaRepository.findById(dto.getIdCuenta())
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta asociada no existe con ID: " + dto.getIdCuenta()));

        Tarjeta tarjeta = tarjetaMapper.toEntity(dto, cuenta);
        Tarjeta guardada = tarjetaRepository.save(tarjeta);
        return tarjetaMapper.toDTO(guardada);
    }

    @Override
    @Transactional(readOnly = true)
    public Tarjeta buscarEntidadPorId(Long idTarjeta) {
        return tarjetaRepository.findById(idTarjeta)
                .orElseThrow(() -> new ResourceNotFoundException("Tarjeta no encontrada con ID: " + idTarjeta));
    }

    @Override
    @Transactional
    public Tarjeta buscarEntidadParaActualizar(Long idTarjeta) {
        return tarjetaRepository.findByIdForUpdate(idTarjeta)
                .orElseThrow(() -> new ResourceNotFoundException("Tarjeta no encontrada con ID: " + idTarjeta));
    }

    @Override
    public void validarTarjetaParaOperar(Tarjeta tarjeta, Long idCuentaOrigen) {
        // 1. Validar expiración de la tarjeta
        tarjeta.validarVigencia();

        // 2. Validar que la tarjeta pertenezca a la cuenta origen especificada si es de débito
        if (tarjeta.isDebito() && tarjeta.getCuenta() != null) {
            if (!tarjeta.getCuenta().getIdCuenta().equals(idCuentaOrigen)) {
                throw new BusinessException(String.format("La tarjeta de débito %s no pertenece a la cuenta de origen especificada.",
                        tarjeta.getNumeroTarjeta()));
            }
        }
    }
}
