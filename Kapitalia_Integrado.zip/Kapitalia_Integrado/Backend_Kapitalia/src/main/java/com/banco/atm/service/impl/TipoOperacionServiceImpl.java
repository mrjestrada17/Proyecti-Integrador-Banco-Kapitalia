package com.banco.atm.service.impl;

import com.banco.atm.dto.TipoOperacionDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.TipoOperacionMapper;
import com.banco.atm.model.TipoOperacion;
import com.banco.atm.repository.TipoOperacionRepository;
import com.banco.atm.service.TipoOperacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TipoOperacionServiceImpl implements TipoOperacionService {

    private final TipoOperacionRepository tipoOperacionRepository;
    private final TipoOperacionMapper tipoOperacionMapper;

    @Override
    @Transactional(readOnly = true)
    public List<TipoOperacionDTO> listarTiposOperacion() {
        return tipoOperacionRepository.findAll().stream()
                .map(tipoOperacionMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TipoOperacionDTO obtenerTipoOperacionPorId(Long idTipoOperacion) {
        TipoOperacion tipoOperacion = buscarEntidadPorId(idTipoOperacion);
        return tipoOperacionMapper.toDTO(tipoOperacion);
    }

    @Override
    @Transactional(readOnly = true)
    public TipoOperacionDTO obtenerPorNombre(String nombreOperacion) {
        TipoOperacion tipoOperacion = tipoOperacionRepository.findByNombreOperacionIgnoreCase(nombreOperacion)
                .orElseThrow(() -> new ResourceNotFoundException("Tipo de operación no encontrado con nombre: " + nombreOperacion));
        return tipoOperacionMapper.toDTO(tipoOperacion);
    }

    @Override
    @Transactional
    public TipoOperacionDTO crearTipoOperacion(TipoOperacionDTO dto) {
        if (tipoOperacionRepository.existsByNombreOperacion(dto.getNombreOperacion())) {
            throw new BusinessException("Ya existe un tipo de operación con el nombre: " + dto.getNombreOperacion());
        }
        TipoOperacion entity = tipoOperacionMapper.toEntity(dto);
        TipoOperacion guardada = tipoOperacionRepository.save(entity);
        return tipoOperacionMapper.toDTO(guardada);
    }

    @Override
    @Transactional(readOnly = true)
    public TipoOperacion buscarEntidadPorId(Long idTipoOperacion) {
        return tipoOperacionRepository.findById(idTipoOperacion)
                .orElseThrow(() -> new ResourceNotFoundException("Tipo de operación no encontrado con ID: " + idTipoOperacion));
    }
}
