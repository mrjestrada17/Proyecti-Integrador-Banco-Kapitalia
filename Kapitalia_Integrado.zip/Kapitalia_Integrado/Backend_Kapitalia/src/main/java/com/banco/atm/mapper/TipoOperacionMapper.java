package com.banco.atm.mapper;

import com.banco.atm.dto.TipoOperacionDTO;
import com.banco.atm.model.TipoOperacion;
import org.springframework.stereotype.Component;

@Component
public class TipoOperacionMapper {

    public TipoOperacionDTO toDTO(TipoOperacion entity) {
        if (entity == null) return null;
        return TipoOperacionDTO.builder()
                .idTipoOperacion(entity.getIdTipoOperacion())
                .nombreOperacion(entity.getNombreOperacion())
                .requiereDestino(entity.getRequiereDestino())
                .build();
    }

    public TipoOperacion toEntity(TipoOperacionDTO dto) {
        if (dto == null) return null;
        return TipoOperacion.builder()
                .idTipoOperacion(dto.getIdTipoOperacion())
                .nombreOperacion(dto.getNombreOperacion())
                .requiereDestino(dto.getRequiereDestino())
                .build();
    }
}
