package com.banco.atm.mapper;

import com.banco.atm.dto.TransaccionResponseDTO;
import com.banco.atm.model.Transaccion;
import org.springframework.stereotype.Component;

@Component
public class TransaccionMapper {

    public TransaccionResponseDTO toDTO(Transaccion entity, String mensaje) {
        if (entity == null) return null;
        return TransaccionResponseDTO.builder()
                .idTransaccion(entity.getIdTransaccion())
                .idTarjeta(entity.getTarjeta() != null ? entity.getTarjeta().getIdTarjeta() : null)
                .numeroTarjeta(entity.getTarjeta() != null ? entity.getTarjeta().getNumeroTarjeta() : null)
                .idTipoOperacion(entity.getTipoOperacion() != null ? entity.getTipoOperacion().getIdTipoOperacion() : null)
                .nombreOperacion(entity.getTipoOperacion() != null ? entity.getTipoOperacion().getNombreOperacion() : null)
                .idCuentaOrigen(entity.getCuentaOrigen() != null ? entity.getCuentaOrigen().getIdCuenta() : null)
                .numeroCuentaOrigen(entity.getCuentaOrigen() != null ? entity.getCuentaOrigen().getNumeroCuenta() : null)
                .idCuentaDestino(entity.getCuentaDestino() != null ? entity.getCuentaDestino().getIdCuenta() : null)
                .numeroCuentaDestino(entity.getCuentaDestino() != null ? entity.getCuentaDestino().getNumeroCuenta() : null)
                .monto(entity.getMonto())
                .saldoNuevoOrigen(entity.getCuentaOrigen() != null ? entity.getCuentaOrigen().getSaldoDisponible() : null)
                .fechaHora(entity.getFechaHora())
                .codigoCajero(entity.getCodigoCajero())
                .mensaje(mensaje != null ? mensaje : "Operación procesada")
                .build();
    }

    public TransaccionResponseDTO toDTO(Transaccion entity) {
        return toDTO(entity, "Transacción registrada exitosamente.");
    }
}
