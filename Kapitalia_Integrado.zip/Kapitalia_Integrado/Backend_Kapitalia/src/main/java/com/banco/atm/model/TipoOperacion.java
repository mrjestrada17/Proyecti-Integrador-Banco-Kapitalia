package com.banco.atm.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Objects;

@Entity
@Table(name = "tipo_operacion")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class TipoOperacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tipo_operacion")
    private Long idTipoOperacion;

    @NotBlank(message = "El nombre de la operación es obligatorio")
    @Size(max = 30, message = "El nombre de la operación no puede exceder 30 caracteres")
    @Column(name = "nombre_operacion", nullable = false, unique = true, length = 30)
    private String nombreOperacion; // Consignación, Retiro, Transf. Enviada, Transf. Recibida, Pago Tarjeta, Avance Efectivo

    @NotNull(message = "El indicador requiereDestino es obligatorio")
    @Column(name = "requiere_destino", nullable = false)
    @Builder.Default
    private Boolean requiereDestino = false;

    public boolean isRequiereDestino() {
        return Boolean.TRUE.equals(this.requiereDestino);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TipoOperacion that = (TipoOperacion) o;
        return Objects.equals(idTipoOperacion, that.idTipoOperacion) || Objects.equals(nombreOperacion, that.nombreOperacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreOperacion != null ? nombreOperacion : idTipoOperacion);
    }
}
