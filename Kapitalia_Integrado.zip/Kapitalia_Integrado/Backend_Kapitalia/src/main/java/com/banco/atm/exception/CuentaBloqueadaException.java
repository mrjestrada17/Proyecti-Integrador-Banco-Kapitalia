package com.banco.atm.exception;

public class CuentaBloqueadaException extends BusinessException {
    public CuentaBloqueadaException(String message) {
        super(message);
    }
}
