package com.banco.atm.service.strategy;

import org.springframework.stereotype.Component;

@Component
public class PagoTarjetaStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Pago Tarjeta".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        // Debitar de la cuenta origen
        context.getCuentaOrigen().debitar(context.getMonto());

        // Si es de crédito, restablecer el cupo de avance
        if (context.getTarjeta().isCredito()) {
            context.getTarjeta().restablecerCupo(context.getMonto());
        }

        context.setMensajeResultado(String.format("Pago de tarjeta por $%s aplicado exitosamente. Saldo cuenta: $%s, Cupo tarjeta: $%s",
                context.getMonto(), context.getCuentaOrigen().getSaldoDisponible(),
                context.getTarjeta().getCupoAvance() != null ? context.getTarjeta().getCupoAvance() : "N/A"));
    }
}
