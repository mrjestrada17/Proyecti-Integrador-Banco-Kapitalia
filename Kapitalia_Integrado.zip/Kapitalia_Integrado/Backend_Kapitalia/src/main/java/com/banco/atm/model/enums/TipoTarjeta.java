package com.banco.atm.model.enums;

import lombok.Getter;

@Getter
public enum TipoTarjeta {
    DEBITO("Debito"),
    CREDITO("Credito");

    private final String descripcion;

    TipoTarjeta(String descripcion) {
        this.descripcion = descripcion;
    }

    public static TipoTarjeta fromString(String valor) {
        for (TipoTarjeta tipo : values()) {
            if (tipo.descripcion.equalsIgnoreCase(valor) || tipo.name().equalsIgnoreCase(valor)) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Tipo de tarjeta no válido: " + valor);
    }
}
