package com.banco.atm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TipoOperacionDTO {
    private Long idTipoOperacion;
    private String nombreOperacion;
    private Boolean requiereDestino;
}
