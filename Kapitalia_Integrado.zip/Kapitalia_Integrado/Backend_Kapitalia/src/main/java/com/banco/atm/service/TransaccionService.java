package com.banco.atm.service;

import com.banco.atm.dto.*;

import java.util.List;

public interface TransaccionService {
    TransaccionResponseDTO procesarTransaccion(TransaccionRequestDTO request);
    TransaccionResponseDTO obtenerTransaccionPorId(Long idTransaccion);
    List<TransaccionResponseDTO> obtenerTransaccionesPorTarjeta(Long idTarjeta);
    List<TransaccionResponseDTO> obtenerTransaccionesPorCuenta(Long idCuenta);
    List<TransaccionResponseDTO> listarUltimasTransacciones();

    // Métodos delegados para retrocompatibilidad
    List<CuentaDTO> listarCuentas();
    List<TarjetaDTO> listarTarjetas();
    List<TipoOperacionDTO> listarTiposOperacion();
    CuentaDTO obtenerCuentaPorId(Long idCuenta);
}
