package com.banco.atm.model.enums;

import lombok.Getter;

@Getter
public enum TipoCuenta {
    AHORROS("Ahorros"),
    CORRIENTE("Corriente");

    private final String descripcion;

    TipoCuenta(String descripcion) {
        this.descripcion = descripcion;
    }

    public static TipoCuenta fromString(String valor) {
        for (TipoCuenta tipo : values()) {
            if (tipo.descripcion.equalsIgnoreCase(valor) || tipo.name().equalsIgnoreCase(valor)) {
                return tipo;
            }
        }
        throw new IllegalArgumentException("Tipo de cuenta no válido: " + valor);
    }
}
