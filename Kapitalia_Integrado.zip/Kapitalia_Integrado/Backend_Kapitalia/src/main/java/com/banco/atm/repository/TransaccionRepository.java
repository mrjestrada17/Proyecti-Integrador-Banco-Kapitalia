package com.banco.atm.repository;

import com.banco.atm.model.Transaccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransaccionRepository extends JpaRepository<Transaccion, Long> {

    List<Transaccion> findByTarjetaIdTarjeta(Long idTarjeta);

    List<Transaccion> findByCuentaOrigenIdCuenta(Long idCuenta);

    List<Transaccion> findByCuentaOrigenIdCuentaOrCuentaDestinoIdCuentaOrderByFechaHoraDesc(Long idCuentaOrigen, Long idCuentaDestino);

    List<Transaccion> findTop10ByCuentaOrigenIdCuentaOrderByFechaHoraDesc(Long idCuenta);

    @Query("SELECT t FROM Transaccion t WHERE t.fechaHora BETWEEN :inicio AND :fin ORDER BY t.fechaHora DESC")
    List<Transaccion> findByFechaHoraBetween(@Param("inicio") LocalDateTime inicio, @Param("fin") LocalDateTime fin);

    @Query("SELECT t FROM Transaccion t ORDER BY t.fechaHora DESC")
    List<Transaccion> findAllOrderByFechaHoraDesc();
}
