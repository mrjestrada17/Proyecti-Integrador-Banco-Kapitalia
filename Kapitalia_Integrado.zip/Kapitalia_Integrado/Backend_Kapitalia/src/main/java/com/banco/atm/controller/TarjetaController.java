package com.banco.atm.controller;

import com.banco.atm.dto.TarjetaDTO;
import com.banco.atm.service.TarjetaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tarjetas")
@RequiredArgsConstructor
@Tag(name = "Tarjetas", description = "Endpoints para la consulta y registro de tarjetas de débito y crédito")
public class TarjetaController {

    private final TarjetaService tarjetaService;

    @GetMapping
    @Operation(summary = "Obtener todas las tarjetas registradas")
    public ResponseEntity<List<TarjetaDTO>> listarTarjetas() {
        return ResponseEntity.ok(tarjetaService.listarTarjetas());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener detalles de una tarjeta por ID")
    public ResponseEntity<TarjetaDTO> obtenerTarjetaPorId(@PathVariable Long id) {
        return ResponseEntity.ok(tarjetaService.obtenerTarjetaPorId(id));
    }

    @GetMapping("/numero/{numeroTarjeta}")
    @Operation(summary = "Obtener detalles de una tarjeta por número")
    public ResponseEntity<TarjetaDTO> obtenerTarjetaPorNumero(@PathVariable String numeroTarjeta) {
        return ResponseEntity.ok(tarjetaService.obtenerTarjetaPorNumero(numeroTarjeta));
    }

    @GetMapping("/cuenta/{idCuenta}")
    @Operation(summary = "Obtener tarjetas asociadas a una cuenta")
    public ResponseEntity<List<TarjetaDTO>> listarPorCuenta(@PathVariable Long idCuenta) {
        return ResponseEntity.ok(tarjetaService.listarPorCuenta(idCuenta));
    }

    @PostMapping
    @Operation(summary = "Registrar una nueva tarjeta")
    public ResponseEntity<TarjetaDTO> crearTarjeta(@Valid @RequestBody TarjetaDTO dto) {
        return new ResponseEntity<>(tarjetaService.crearTarjeta(dto), HttpStatus.CREATED);
    }
}
