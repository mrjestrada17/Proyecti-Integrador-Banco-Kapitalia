package com.banco.atm.repository;

import com.banco.atm.model.Tarjeta;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TarjetaRepository extends JpaRepository<Tarjeta, Long> {

    Optional<Tarjeta> findByNumeroTarjeta(String numeroTarjeta);

    boolean existsByNumeroTarjeta(String numeroTarjeta);

    List<Tarjeta> findByCuentaIdCuenta(Long idCuenta);

    /**
     * Bloqueo pesimista para actualización concurrente de cupos en tarjetas de crédito.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT t FROM Tarjeta t WHERE t.idTarjeta = :id")
    Optional<Tarjeta> findByIdForUpdate(@Param("id") Long id);
}
