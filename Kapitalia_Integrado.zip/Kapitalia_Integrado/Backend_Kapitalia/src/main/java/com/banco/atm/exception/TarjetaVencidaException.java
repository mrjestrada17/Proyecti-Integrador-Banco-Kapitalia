package com.banco.atm.exception;

public class TarjetaVencidaException extends BusinessException {
    public TarjetaVencidaException(String message) {
        super(message);
    }
}
