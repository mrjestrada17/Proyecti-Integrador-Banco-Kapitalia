package com.banco.atm.mapper;

import com.banco.atm.dto.TarjetaDTO;
import com.banco.atm.model.Cuenta;
import com.banco.atm.model.Tarjeta;
import org.springframework.stereotype.Component;

@Component
public class TarjetaMapper {

    public TarjetaDTO toDTO(Tarjeta entity) {
        if (entity == null) return null;
        return TarjetaDTO.builder()
                .idTarjeta(entity.getIdTarjeta())
                .idCuenta(entity.getCuenta() != null ? entity.getCuenta().getIdCuenta() : null)
                .numeroTarjeta(entity.getNumeroTarjeta())
                .tipoTarjeta(entity.getTipoTarjeta())
                .cupoAvance(entity.getCupoAvance())
                .fechaVencimiento(entity.getFechaVencimiento())
                .build();
    }

    public Tarjeta toEntity(TarjetaDTO dto, Cuenta cuenta) {
        if (dto == null) return null;
        return Tarjeta.builder()
                .idTarjeta(dto.getIdTarjeta())
                .cuenta(cuenta)
                .numeroTarjeta(dto.getNumeroTarjeta())
                .tipoTarjeta(dto.getTipoTarjeta())
                .cupoAvance(dto.getCupoAvance())
                .fechaVencimiento(dto.getFechaVencimiento())
                .build();
    }
}
