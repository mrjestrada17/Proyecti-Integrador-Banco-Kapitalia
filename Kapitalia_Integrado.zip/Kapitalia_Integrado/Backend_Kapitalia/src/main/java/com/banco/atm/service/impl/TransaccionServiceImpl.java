package com.banco.atm.service.impl;

import com.banco.atm.dto.*;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.CuentaMapper;
import com.banco.atm.mapper.TarjetaMapper;
import com.banco.atm.mapper.TipoOperacionMapper;
import com.banco.atm.mapper.TransaccionMapper;
import com.banco.atm.model.*;
import com.banco.atm.repository.*;
import com.banco.atm.service.CuentaService;
import com.banco.atm.service.TarjetaService;
import com.banco.atm.service.TipoOperacionService;
import com.banco.atm.service.TransaccionService;
import com.banco.atm.service.strategy.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TransaccionServiceImpl implements TransaccionService {

    private final CuentaRepository cuentaRepository;
    private final TarjetaRepository tarjetaRepository;
    private final TipoOperacionRepository tipoOperacionRepository;
    private final TransaccionRepository transaccionRepository;

    @Autowired(required = false)
    private OperacionStrategyFactory strategyFactory;

    @Autowired(required = false)
    private TransaccionMapper transaccionMapper;

    @Autowired(required = false)
    private CuentaService cuentaService;

    @Autowired(required = false)
    private TarjetaService tarjetaService;

    @Autowired(required = false)
    private TipoOperacionService tipoOperacionService;

    @Autowired(required = false)
    private CuentaMapper cuentaMapper;

    @Autowired(required = false)
    private TarjetaMapper tarjetaMapper;

    @Autowired(required = false)
    private TipoOperacionMapper tipoOperacionMapper;

    private OperacionStrategyFactory getStrategyFactory() {
        if (this.strategyFactory == null) {
            this.strategyFactory = new OperacionStrategyFactory(Arrays.asList(
                    new RetiroStrategy(),
                    new ConsignacionStrategy(),
                    new TransferenciaEnviadaStrategy(),
                    new TransferenciaRecibidaStrategy(),
                    new PagoTarjetaStrategy(),
                    new AvanceEfectivoStrategy()
            ));
        }
        return this.strategyFactory;
    }

    private TransaccionMapper getTransaccionMapper() {
        if (this.transaccionMapper == null) {
            this.transaccionMapper = new TransaccionMapper();
        }
        return this.transaccionMapper;
    }

    private CuentaMapper getCuentaMapper() {
        if (this.cuentaMapper == null) {
            this.cuentaMapper = new CuentaMapper();
        }
        return this.cuentaMapper;
    }

    private TarjetaMapper getTarjetaMapper() {
        if (this.tarjetaMapper == null) {
            this.tarjetaMapper = new TarjetaMapper();
        }
        return this.tarjetaMapper;
    }

    private TipoOperacionMapper getTipoOperacionMapper() {
        if (this.tipoOperacionMapper == null) {
            this.tipoOperacionMapper = new TipoOperacionMapper();
        }
        return this.tipoOperacionMapper;
    }

    @Override
    @Transactional
    public TransaccionResponseDTO procesarTransaccion(TransaccionRequestDTO request) {
        // 1. Validar Monto Positivo
        if (request.getMonto() == null || request.getMonto().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("El monto de la transacción debe ser un valor positivo mayor a 0.");
        }

        // 2. Validar Tarjeta
        Tarjeta tarjeta = tarjetaRepository.findById(request.getIdTarjeta())
                .orElseThrow(() -> new BusinessException("La tarjeta especificada no existe con ID: " + request.getIdTarjeta()));

        // Validar vigencia de tarjeta
        tarjeta.validarVigencia();

        // 3. Validar Tipo de Operación
        TipoOperacion tipoOperacion = tipoOperacionRepository.findById(request.getIdTipoOperacion())
                .orElseThrow(() -> new BusinessException("El tipo de operación no existe con ID: " + request.getIdTipoOperacion()));

        // 4. Validar Cuenta Origen
        Cuenta cuentaOrigen = cuentaRepository.findById(request.getIdCuentaOrigen())
                .orElseThrow(() -> new BusinessException("La cuenta de origen no existe con ID: " + request.getIdCuentaOrigen()));

        if (!"Activa".equalsIgnoreCase(cuentaOrigen.getEstado())) {
            throw new BusinessException("La cuenta de origen no se encuentra 'Activa'. Estado actual: " + cuentaOrigen.getEstado());
        }

        // 5. Validar Cuenta Destino si la operación lo requiere
        Cuenta cuentaDestino = null;
        if (Boolean.TRUE.equals(tipoOperacion.getRequiereDestino())) {
            if (request.getIdCuentaDestino() == null) {
                throw new BusinessException("La operación '" + tipoOperacion.getNombreOperacion() + "' requiere una cuenta de destino.");
            }
            if (request.getIdCuentaOrigen().equals(request.getIdCuentaDestino())) {
                throw new BusinessException("La cuenta de origen y destino no pueden ser idénticas para esta operación.");
            }
            cuentaDestino = cuentaRepository.findById(request.getIdCuentaDestino())
                    .orElseThrow(() -> new BusinessException("La cuenta de destino no existe con ID: " + request.getIdCuentaDestino()));

            if (!"Activa".equalsIgnoreCase(cuentaDestino.getEstado())) {
                throw new BusinessException("La cuenta de destino no se encuentra 'Activa'.");
            }
        } else if (request.getIdCuentaDestino() != null) {
            cuentaDestino = cuentaRepository.findById(request.getIdCuentaDestino()).orElse(null);
        }

        // 6. Ejecutar Lógica de Negocio mediante Strategy Pattern
        TransaccionContext context = TransaccionContext.builder()
                .tarjeta(tarjeta)
                .tipoOperacion(tipoOperacion)
                .cuentaOrigen(cuentaOrigen)
                .cuentaDestino(cuentaDestino)
                .monto(request.getMonto())
                .codigoCajero(request.getCodigoCajero())
                .build();

        OperacionStrategy strategy = getStrategyFactory().getStrategy(tipoOperacion.getNombreOperacion());
        strategy.ejecutar(context);

        // Guardar cambios en cuenta origen
        cuentaRepository.save(cuentaOrigen);

        // Guardar cambios en cuenta destino si aplica
        if (cuentaDestino != null) {
            cuentaRepository.save(cuentaDestino);
        }

        // Guardar cambios en tarjeta si fue modificada (por ej. cupo en crédito)
        if (tarjeta.isCredito()) {
            tarjetaRepository.save(tarjeta);
        }

        // 7. Registrar Histórico de Transacción
        Transaccion transaccion = Transaccion.builder()
                .tarjeta(tarjeta)
                .tipoOperacion(tipoOperacion)
                .cuentaOrigen(cuentaOrigen)
                .cuentaDestino(cuentaDestino)
                .monto(request.getMonto())
                .fechaHora(LocalDateTime.now())
                .codigoCajero(request.getCodigoCajero())
                .build();

        Transaccion guardada = transaccionRepository.save(transaccion);

        String mensaje = context.getMensajeResultado() != null
                ? context.getMensajeResultado()
                : "Operación '" + tipoOperacion.getNombreOperacion() + "' procesada exitosamente en el cajero " + request.getCodigoCajero() + ".";

        return getTransaccionMapper().toDTO(guardada, mensaje);
    }

    @Override
    @Transactional(readOnly = true)
    public TransaccionResponseDTO obtenerTransaccionPorId(Long idTransaccion) {
        Transaccion transaccion = transaccionRepository.findById(idTransaccion)
                .orElseThrow(() -> new ResourceNotFoundException("Transacción no encontrada con ID: " + idTransaccion));
        return getTransaccionMapper().toDTO(transaccion);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransaccionResponseDTO> obtenerTransaccionesPorTarjeta(Long idTarjeta) {
        return transaccionRepository.findByTarjetaIdTarjeta(idTarjeta).stream()
                .map(getTransaccionMapper()::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransaccionResponseDTO> obtenerTransaccionesPorCuenta(Long idCuenta) {
        return transaccionRepository.findByCuentaOrigenIdCuenta(idCuenta).stream()
                .map(getTransaccionMapper()::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransaccionResponseDTO> listarUltimasTransacciones() {
        return transaccionRepository.findAllOrderByFechaHoraDesc().stream()
                .map(getTransaccionMapper()::toDTO)
                .collect(Collectors.toList());
    }

    // ==========================================
    // Métodos Delegados para Retrocompatibilidad
    // ==========================================

    @Override
    @Transactional(readOnly = true)
    public List<CuentaDTO> listarCuentas() {
        if (cuentaService != null) {
            return cuentaService.listarCuentas();
        }
        return cuentaRepository.findAll().stream()
                .map(getCuentaMapper()::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TarjetaDTO> listarTarjetas() {
        if (tarjetaService != null) {
            return tarjetaService.listarTarjetas();
        }
        return tarjetaRepository.findAll().stream()
                .map(getTarjetaMapper()::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TipoOperacionDTO> listarTiposOperacion() {
        if (tipoOperacionService != null) {
            return tipoOperacionService.listarTiposOperacion();
        }
        return tipoOperacionRepository.findAll().stream()
                .map(getTipoOperacionMapper()::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CuentaDTO obtenerCuentaPorId(Long idCuenta) {
        if (cuentaService != null) {
            return cuentaService.obtenerCuentaPorId(idCuenta);
        }
        Cuenta c = cuentaRepository.findById(idCuenta)
                .orElseThrow(() -> new BusinessException("Cuenta no encontrada con ID: " + idCuenta));
        return getCuentaMapper().toDTO(c);
    }
}
