package com.banco.atm.model;

import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.TarjetaVencidaException;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "tarjeta")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "cuenta")
public class Tarjeta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tarjeta")
    private Long idTarjeta;

    @NotNull(message = "La tarjeta debe estar asociada a una cuenta")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cuenta", nullable = false)
    private Cuenta cuenta;

    @NotBlank(message = "El número de tarjeta es obligatorio")
    @Size(min = 16, max = 16, message = "El número de tarjeta debe tener exactamente 16 dígitos")
    @Column(name = "numero_tarjeta", nullable = false, unique = true, length = 16)
    private String numeroTarjeta;

    @NotBlank(message = "El tipo de tarjeta es obligatorio")
    @Column(name = "tipo_tarjeta", nullable = false, length = 10)
    private String tipoTarjeta; // 'Debito', 'Credito'

    @Column(name = "cupo_avance", precision = 12, scale = 2, nullable = true)
    private BigDecimal cupoAvance;

    @NotNull(message = "La fecha de vencimiento es obligatoria")
    @Column(name = "fecha_vencimiento", nullable = false)
    private LocalDate fechaVencimiento;

    // ==========================================
    // Métodos de Dominio (Rich Domain Model / DDD)
    // ==========================================

    public boolean isCredito() {
        return "Credito".equalsIgnoreCase(this.tipoTarjeta);
    }

    public boolean isDebito() {
        return "Debito".equalsIgnoreCase(this.tipoTarjeta);
    }

    public boolean isVencida() {
        return this.fechaVencimiento != null && this.fechaVencimiento.isBefore(LocalDate.now());
    }

    public void validarVigencia() {
        if (isVencida()) {
            throw new TarjetaVencidaException("La tarjeta número " + this.numeroTarjeta + " se encuentra vencida desde: " + this.fechaVencimiento);
        }
    }

    /**
     * Descuenta del cupo disponible para avances de tarjeta de crédito.
     */
    public void descontarCupo(BigDecimal monto) {
        if (!isCredito()) {
            throw new BusinessException("Solo las tarjetas de Crédito poseen cupo para avance.");
        }
        if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("El monto a descontar debe ser un valor positivo mayor a 0.");
        }
        BigDecimal cupoActual = this.cupoAvance != null ? this.cupoAvance : BigDecimal.ZERO;
        if (cupoActual.compareTo(monto) < 0) {
            throw new BusinessException(String.format("Cupo de avance insuficiente en la tarjeta de crédito. Cupo disponible: $%s, Solicitado: $%s",
                    cupoActual, monto));
        }
        this.cupoAvance = cupoActual.subtract(monto);
    }

    /**
     * Restablece el cupo de avance tras un pago o abono a la tarjeta de crédito.
     */
    public void restablecerCupo(BigDecimal monto) {
        if (!isCredito()) {
            return;
        }
        if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("El monto a restablecer debe ser positivo.");
        }
        BigDecimal cupoActual = this.cupoAvance != null ? this.cupoAvance : BigDecimal.ZERO;
        this.cupoAvance = cupoActual.add(monto);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tarjeta tarjeta = (Tarjeta) o;
        return Objects.equals(idTarjeta, tarjeta.idTarjeta) || Objects.equals(numeroTarjeta, tarjeta.numeroTarjeta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroTarjeta != null ? numeroTarjeta : idTarjeta);
    }
}
