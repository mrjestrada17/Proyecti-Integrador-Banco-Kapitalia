package com.banco.atm.service.strategy;

import org.springframework.stereotype.Component;

@Component
public class ConsignacionStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Consignación".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "")
                || "Consignacion".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        if (context.getCuentaDestino() != null) {
            context.getCuentaDestino().acreditar(context.getMonto());
            context.setMensajeResultado(String.format("Consignación exitosa por $%s a la cuenta destino %s.",
                    context.getMonto(), context.getCuentaDestino().getNumeroCuenta()));
        } else {
            context.getCuentaOrigen().acreditar(context.getMonto());
            context.setMensajeResultado(String.format("Consignación exitosa por $%s a la cuenta %s. Nuevo saldo: $%s",
                    context.getMonto(), context.getCuentaOrigen().getNumeroCuenta(), context.getCuentaOrigen().getSaldoDisponible()));
        }
    }
}
