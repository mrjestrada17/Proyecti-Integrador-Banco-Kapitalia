package com.banco.atm.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API Sistema Bancario & Cajero Automático (ATM)")
                        .version("1.0.0")
                        .description("API REST para la gestión de Cuentas, Tarjetas, Tipos de Operación y Transacciones bancarias.")
                        .contact(new Contact()
                                .name("Equipo de Arquitectura Bancaria")
                                .email("soporte@banco.com")));
    }
}
