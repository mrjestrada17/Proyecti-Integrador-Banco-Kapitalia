package com.banco.atm.service.strategy;

public interface OperacionStrategy {
    boolean soporta(String nombreOperacion);
    void ejecutar(TransaccionContext context);
}
