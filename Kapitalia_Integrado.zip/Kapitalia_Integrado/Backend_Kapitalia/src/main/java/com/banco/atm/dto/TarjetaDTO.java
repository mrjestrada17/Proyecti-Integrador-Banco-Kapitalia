package com.banco.atm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TarjetaDTO {
    private Long idTarjeta;
    private Long idCuenta;
    private String numeroTarjeta;
    private String tipoTarjeta;
    private BigDecimal cupoAvance;
    private LocalDate fechaVencimiento;
}
