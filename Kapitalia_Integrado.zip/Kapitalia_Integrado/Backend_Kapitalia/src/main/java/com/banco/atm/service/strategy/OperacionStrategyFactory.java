package com.banco.atm.service.strategy;

import com.banco.atm.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class OperacionStrategyFactory {

    private final List<OperacionStrategy> strategies;

    public OperacionStrategy getStrategy(String nombreOperacion) {
        if (nombreOperacion == null || nombreOperacion.trim().isEmpty()) {
            throw new BusinessException("El nombre de la operación no puede ser nulo o vacío.");
        }
        return strategies.stream()
                .filter(s -> s.soporta(nombreOperacion))
                .findFirst()
                .orElseThrow(() -> new BusinessException("Tipo de operación no reconocido: " + nombreOperacion));
    }
}
