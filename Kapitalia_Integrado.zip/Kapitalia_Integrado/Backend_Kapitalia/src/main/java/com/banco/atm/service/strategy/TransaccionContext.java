package com.banco.atm.service.strategy;

import com.banco.atm.model.Cuenta;
import com.banco.atm.model.Tarjeta;
import com.banco.atm.model.TipoOperacion;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransaccionContext {
    private Tarjeta tarjeta;
    private TipoOperacion tipoOperacion;
    private Cuenta cuentaOrigen;
    private Cuenta cuentaDestino;
    private BigDecimal monto;
    private String codigoCajero;
    private String mensajeResultado;
}
