package com.banco.atm.service.strategy;

import com.banco.atm.exception.BusinessException;
import org.springframework.stereotype.Component;

@Component
public class AvanceEfectivoStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Avance Efectivo".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "")
                || "Avance".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        if (!context.getTarjeta().isCredito()) {
            throw new BusinessException("Los avances en efectivo solo están permitidos para tarjetas de Crédito.");
        }

        // Descontar del cupo disponible de la tarjeta
        context.getTarjeta().descontarCupo(context.getMonto());

        // Acreditar fondos a la cuenta de origen para su posterior retiro o uso
        context.getCuentaOrigen().acreditar(context.getMonto());

        context.setMensajeResultado(String.format("Avance en efectivo exitoso por $%s. Cupo restante: $%s. Saldo abonado en cuenta: $%s",
                context.getMonto(), context.getTarjeta().getCupoAvance(), context.getCuentaOrigen().getSaldoDisponible()));
    }
}
