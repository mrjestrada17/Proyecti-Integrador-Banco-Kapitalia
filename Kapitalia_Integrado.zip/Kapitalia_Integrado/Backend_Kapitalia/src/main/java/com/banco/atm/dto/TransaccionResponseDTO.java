package com.banco.atm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransaccionResponseDTO {
    private Long idTransaccion;
    private Long idTarjeta;
    private String numeroTarjeta;
    private Long idTipoOperacion;
    private String nombreOperacion;
    private Long idCuentaOrigen;
    private String numeroCuentaOrigen;
    private Long idCuentaDestino;
    private String numeroCuentaDestino;
    private BigDecimal monto;
    private BigDecimal saldoNuevoOrigen;
    private LocalDateTime fechaHora;
    private String codigoCajero;
    private String mensaje;
}
