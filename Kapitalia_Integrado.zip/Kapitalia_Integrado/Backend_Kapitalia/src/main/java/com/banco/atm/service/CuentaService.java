package com.banco.atm.service;

import com.banco.atm.dto.CuentaDTO;
import com.banco.atm.model.Cuenta;

import java.math.BigDecimal;
import java.util.List;

public interface CuentaService {
    List<CuentaDTO> listarCuentas();
    CuentaDTO obtenerCuentaPorId(Long idCuenta);
    CuentaDTO obtenerCuentaPorNumero(String numeroCuenta);
    CuentaDTO crearCuenta(CuentaDTO dto);
    CuentaDTO actualizarSaldo(Long idCuenta, BigDecimal nuevoSaldo);
    CuentaDTO cambiarEstado(Long idCuenta, String nuevoEstado);
    Cuenta buscarEntidadPorId(Long idCuenta);
    Cuenta buscarEntidadParaActualizar(Long idCuenta);
}
