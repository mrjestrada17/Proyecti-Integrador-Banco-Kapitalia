package com.banco.atm.service.strategy;

import org.springframework.stereotype.Component;

@Component
public class RetiroStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Retiro".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        context.getCuentaOrigen().debitar(context.getMonto());
        context.setMensajeResultado(String.format("Retiro exitoso por $%s. Nuevo saldo: $%s",
                context.getMonto(), context.getCuentaOrigen().getSaldoDisponible()));
    }
}
