package com.banco.atm.service.strategy;

import com.banco.atm.exception.BusinessException;
import org.springframework.stereotype.Component;

@Component
public class TransferenciaEnviadaStrategy implements OperacionStrategy {

    @Override
    public boolean soporta(String nombreOperacion) {
        return "Transf. Enviada".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "")
                || "Transferencia Enviada".equalsIgnoreCase(nombreOperacion != null ? nombreOperacion.trim() : "");
    }

    @Override
    public void ejecutar(TransaccionContext context) {
        if (context.getCuentaDestino() == null) {
            throw new BusinessException("La transferencia requiere especificar una cuenta de destino.");
        }
        if (context.getCuentaOrigen().getIdCuenta().equals(context.getCuentaDestino().getIdCuenta())) {
            throw new BusinessException("La cuenta de origen y de destino no pueden ser iguales para una transferencia.");
        }

        context.getCuentaOrigen().debitar(context.getMonto());
        context.getCuentaDestino().acreditar(context.getMonto());

        context.setMensajeResultado(String.format("Transferencia enviada exitosamente por $%s a la cuenta %s. Nuevo saldo origen: $%s",
                context.getMonto(), context.getCuentaDestino().getNumeroCuenta(), context.getCuentaOrigen().getSaldoDisponible()));
    }
}
