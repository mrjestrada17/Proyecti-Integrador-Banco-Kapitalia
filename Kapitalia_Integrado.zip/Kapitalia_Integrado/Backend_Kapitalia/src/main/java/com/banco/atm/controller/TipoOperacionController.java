package com.banco.atm.controller;

import com.banco.atm.dto.TipoOperacionDTO;
import com.banco.atm.service.TipoOperacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tipos-operacion")
@RequiredArgsConstructor
@Tag(name = "Tipos de Operación", description = "Endpoints para consultar operaciones bancarias soportadas")
public class TipoOperacionController {

    private final TipoOperacionService tipoOperacionService;

    @GetMapping
    @Operation(summary = "Listar los tipos de operaciones bancarias disponibles")
    public ResponseEntity<List<TipoOperacionDTO>> listarTiposOperacion() {
        return ResponseEntity.ok(tipoOperacionService.listarTiposOperacion());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener tipo de operación por ID")
    public ResponseEntity<TipoOperacionDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(tipoOperacionService.obtenerTipoOperacionPorId(id));
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo tipo de operación bancaria")
    public ResponseEntity<TipoOperacionDTO> crearTipoOperacion(@Valid @RequestBody TipoOperacionDTO dto) {
        return new ResponseEntity<>(tipoOperacionService.crearTipoOperacion(dto), HttpStatus.CREATED);
    }
}
