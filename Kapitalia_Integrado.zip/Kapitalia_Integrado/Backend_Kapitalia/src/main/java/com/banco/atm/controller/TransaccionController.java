package com.banco.atm.controller;

import com.banco.atm.dto.TransaccionRequestDTO;
import com.banco.atm.dto.TransaccionResponseDTO;
import com.banco.atm.service.TransaccionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transacciones")
@RequiredArgsConstructor
@Tag(name = "Transacciones", description = "Endpoints para procesar y consultar operaciones del Cajero Automático (ATM)")
public class TransaccionController {

    private final TransaccionService transaccionService;

    @PostMapping
    @Operation(summary = "Procesar una transacción en el cajero automático (Retiro, Depósito, Transferencia, Consulta)")
    public ResponseEntity<TransaccionResponseDTO> procesarTransaccion(@Valid @RequestBody TransaccionRequestDTO request) {
        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Listar todas las transacciones ordenadas cronológicamente")
    public ResponseEntity<List<TransaccionResponseDTO>> listarUltimasTransacciones() {
        return ResponseEntity.ok(transaccionService.listarUltimasTransacciones());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Consultar detalle de una transacción por ID")
    public ResponseEntity<TransaccionResponseDTO> obtenerTransaccionPorId(@PathVariable Long id) {
        return ResponseEntity.ok(transaccionService.obtenerTransaccionPorId(id));
    }

    @GetMapping("/tarjeta/{idTarjeta}")
    @Operation(summary = "Obtener historial de transacciones asociadas a una tarjeta")
    public ResponseEntity<List<TransaccionResponseDTO>> obtenerPorTarjeta(@PathVariable Long idTarjeta) {
        return ResponseEntity.ok(transaccionService.obtenerTransaccionesPorTarjeta(idTarjeta));
    }

    @GetMapping("/cuenta/{idCuenta}")
    @Operation(summary = "Obtener historial de transacciones asociadas a una cuenta de origen")
    public ResponseEntity<List<TransaccionResponseDTO>> obtenerPorCuenta(@PathVariable Long idCuenta) {
        return ResponseEntity.ok(transaccionService.obtenerTransaccionesPorCuenta(idCuenta));
    }
}
