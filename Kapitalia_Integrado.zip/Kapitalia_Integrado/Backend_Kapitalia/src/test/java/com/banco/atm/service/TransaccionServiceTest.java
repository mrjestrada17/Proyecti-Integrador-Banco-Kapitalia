package com.banco.atm.service;

import com.banco.atm.dto.TransaccionRequestDTO;
import com.banco.atm.dto.TransaccionResponseDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.SaldoInsuficienteException;
import com.banco.atm.model.*;
import com.banco.atm.repository.*;
import com.banco.atm.service.impl.TransaccionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransaccionServiceTest {

    @Mock
    private CuentaRepository cuentaRepository;
    @Mock
    private TarjetaRepository tarjetaRepository;
    @Mock
    private TipoOperacionRepository tipoOperacionRepository;
    @Mock
    private TransaccionRepository transaccionRepository;

    @InjectMocks
    private TransaccionServiceImpl transaccionService;

    private Cuenta cuentaOrigen;
    private Cuenta cuentaDestino;
    private Tarjeta tarjetaDebito;
    private Tarjeta tarjetaCredito;
    private TipoOperacion opRetiro;
    private TipoOperacion opConsignacion;
    private TipoOperacion opTransferencia;
    private TipoOperacion opPagoTarjeta;
    private TipoOperacion opAvance;

    @BeforeEach
    void setUp() {
        cuentaOrigen = Cuenta.builder()
                .idCuenta(1L)
                .numeroCuenta("1001001001001001")
                .tipoCuenta("Ahorros")
                .saldoDisponible(new BigDecimal("1000.00"))
                .estado("Activa")
                .build();

        cuentaDestino = Cuenta.builder()
                .idCuenta(2L)
                .numeroCuenta("2002002002002002")
                .tipoCuenta("Corriente")
                .saldoDisponible(new BigDecimal("500.00"))
                .estado("Activa")
                .build();

        tarjetaDebito = Tarjeta.builder()
                .idTarjeta(10L)
                .cuenta(cuentaOrigen)
                .numeroTarjeta("4532111122223333")
                .tipoTarjeta("Debito")
                .cupoAvance(null)
                .fechaVencimiento(LocalDate.of(2028, 12, 31))
                .build();

        tarjetaCredito = Tarjeta.builder()
                .idTarjeta(20L)
                .cuenta(cuentaOrigen)
                .numeroTarjeta("5412888899990000")
                .tipoTarjeta("Credito")
                .cupoAvance(new BigDecimal("3000.00"))
                .fechaVencimiento(LocalDate.of(2027, 8, 31))
                .build();

        opRetiro = TipoOperacion.builder()
                .idTipoOperacion(1L)
                .nombreOperacion("Retiro")
                .requiereDestino(false)
                .build();

        opConsignacion = TipoOperacion.builder()
                .idTipoOperacion(2L)
                .nombreOperacion("Consignación")
                .requiereDestino(false)
                .build();

        opTransferencia = TipoOperacion.builder()
                .idTipoOperacion(3L)
                .nombreOperacion("Transf. Enviada")
                .requiereDestino(true)
                .build();

        opPagoTarjeta = TipoOperacion.builder()
                .idTipoOperacion(5L)
                .nombreOperacion("Pago Tarjeta")
                .requiereDestino(false)
                .build();

        opAvance = TipoOperacion.builder()
                .idTipoOperacion(6L)
                .nombreOperacion("Avance Efectivo")
                .requiereDestino(false)
                .build();
    }

    @Test
    @DisplayName("Procesar Retiro exitoso descuenta saldo de cuenta origen")
    void testRetiroExitoso() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L)
                .idTipoOperacion(1L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("200.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(1L)).thenReturn(Optional.of(opRetiro));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));
        when(transaccionRepository.save(any(Transaccion.class))).thenAnswer(i -> {
            Transaccion t = i.getArgument(0);
            t.setIdTransaccion(100L);
            return t;
        });

        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);

        assertNotNull(response);
        assertEquals(new BigDecimal("800.00"), cuentaOrigen.getSaldoDisponible());
        assertEquals("Retiro", response.getNombreOperacion());
        verify(cuentaRepository, times(1)).save(cuentaOrigen);
    }

    @Test
    @DisplayName("Retiro con saldo insuficiente lanza SaldoInsuficienteException")
    void testRetiroSaldoInsuficiente() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L)
                .idTipoOperacion(1L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("1500.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(1L)).thenReturn(Optional.of(opRetiro));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));

        assertThrows(SaldoInsuficienteException.class, () -> transaccionService.procesarTransaccion(request));
    }

    @Test
    @DisplayName("Transferencia exitosa debita de origen y acredita en destino")
    void testTransferenciaExitosa() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L)
                .idTipoOperacion(3L)
                .idCuentaOrigen(1L)
                .idCuentaDestino(2L)
                .monto(new BigDecimal("300.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(3L)).thenReturn(Optional.of(opTransferencia));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));
        when(cuentaRepository.findById(2L)).thenReturn(Optional.of(cuentaDestino));
        when(transaccionRepository.save(any(Transaccion.class))).thenAnswer(i -> {
            Transaccion t = i.getArgument(0);
            t.setIdTransaccion(101L);
            return t;
        });

        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);

        assertNotNull(response);
        assertEquals(new BigDecimal("700.00"), cuentaOrigen.getSaldoDisponible());
        assertEquals(new BigDecimal("800.00"), cuentaDestino.getSaldoDisponible());
        verify(cuentaRepository, times(1)).save(cuentaOrigen);
        verify(cuentaRepository, times(1)).save(cuentaDestino);
    }

    @Test
    @DisplayName("Consignación directa incrementa saldo de cuenta origen")
    void testConsignacionExitosa() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L)
                .idTipoOperacion(2L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("500.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(2L)).thenReturn(Optional.of(opConsignacion));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));
        when(transaccionRepository.save(any(Transaccion.class))).thenAnswer(i -> {
            Transaccion t = i.getArgument(0);
            t.setIdTransaccion(102L);
            return t;
        });

        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);

        assertNotNull(response);
        assertEquals(new BigDecimal("1500.00"), cuentaOrigen.getSaldoDisponible());
    }

    @Test
    @DisplayName("Pago de tarjeta con tarjeta de crédito restablece cupo de avance")
    void testPagoTarjetaCredito() {
        tarjetaCredito.setCupoAvance(new BigDecimal("1000.00")); // Cupo usado previamente
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(20L)
                .idTipoOperacion(5L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("400.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(20L)).thenReturn(Optional.of(tarjetaCredito));
        when(tipoOperacionRepository.findById(5L)).thenReturn(Optional.of(opPagoTarjeta));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));
        when(transaccionRepository.save(any(Transaccion.class))).thenAnswer(i -> {
            Transaccion t = i.getArgument(0);
            t.setIdTransaccion(103L);
            return t;
        });

        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);

        assertNotNull(response);
        assertEquals(new BigDecimal("600.00"), cuentaOrigen.getSaldoDisponible());
        assertEquals(new BigDecimal("1400.00"), tarjetaCredito.getCupoAvance());
        verify(tarjetaRepository, times(1)).save(tarjetaCredito);
    }

    @Test
    @DisplayName("Procesar Avance en Efectivo descuenta cupo de crédito e incrementa saldo")
    void testAvanceEfectivoExitoso() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(20L)
                .idTipoOperacion(6L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("500.00"))
                .codigoCajero("ATM-002")
                .build();

        when(tarjetaRepository.findById(20L)).thenReturn(Optional.of(tarjetaCredito));
        when(tipoOperacionRepository.findById(6L)).thenReturn(Optional.of(opAvance));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));
        when(transaccionRepository.save(any(Transaccion.class))).thenAnswer(i -> {
            Transaccion t = i.getArgument(0);
            t.setIdTransaccion(200L);
            return t;
        });

        TransaccionResponseDTO response = transaccionService.procesarTransaccion(request);

        assertNotNull(response);
        assertEquals(new BigDecimal("2500.00"), tarjetaCredito.getCupoAvance());
        assertEquals(new BigDecimal("1500.00"), cuentaOrigen.getSaldoDisponible());
        verify(tarjetaRepository, times(1)).save(tarjetaCredito);
    }

    @Test
    @DisplayName("Rechazar Avance en Efectivo si la tarjeta es de Débito")
    void testAvanceEfectivoTarjetaDebitoRechazado() {
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L) // Débito
                .idTipoOperacion(6L) // Avance
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("100.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(6L)).thenReturn(Optional.of(opAvance));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));

        assertThrows(BusinessException.class, () -> transaccionService.procesarTransaccion(request));
    }

    @Test
    @DisplayName("Rechazar transacción si la cuenta de origen se encuentra bloqueada")
    void testCuentaOrigenBloqueadaRechazada() {
        cuentaOrigen.setEstado("Bloqueada");
        TransaccionRequestDTO request = TransaccionRequestDTO.builder()
                .idTarjeta(10L)
                .idTipoOperacion(1L)
                .idCuentaOrigen(1L)
                .monto(new BigDecimal("100.00"))
                .codigoCajero("ATM-001")
                .build();

        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));
        when(tipoOperacionRepository.findById(1L)).thenReturn(Optional.of(opRetiro));
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaOrigen));

        assertThrows(BusinessException.class, () -> transaccionService.procesarTransaccion(request));
    }
}
