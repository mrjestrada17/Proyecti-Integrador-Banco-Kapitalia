package com.banco.atm.service;

import com.banco.atm.dto.TarjetaDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.exception.TarjetaVencidaException;
import com.banco.atm.mapper.TarjetaMapper;
import com.banco.atm.model.Cuenta;
import com.banco.atm.model.Tarjeta;
import com.banco.atm.repository.CuentaRepository;
import com.banco.atm.repository.TarjetaRepository;
import com.banco.atm.service.impl.TarjetaServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TarjetaServiceTest {

    @Mock
    private TarjetaRepository tarjetaRepository;

    @Mock
    private CuentaRepository cuentaRepository;

    @Spy
    private TarjetaMapper tarjetaMapper;

    @InjectMocks
    private TarjetaServiceImpl tarjetaService;

    private Cuenta cuenta;
    private Tarjeta tarjetaDebito;
    private Tarjeta tarjetaCredito;

    @BeforeEach
    void setUp() {
        cuenta = Cuenta.builder()
                .idCuenta(1L)
                .numeroCuenta("1001001001001001")
                .tipoCuenta("Ahorros")
                .saldoDisponible(new BigDecimal("1500.00"))
                .estado("Activa")
                .build();

        tarjetaDebito = Tarjeta.builder()
                .idTarjeta(10L)
                .cuenta(cuenta)
                .numeroTarjeta("4532111122223333")
                .tipoTarjeta("Debito")
                .cupoAvance(null)
                .fechaVencimiento(LocalDate.of(2028, 12, 31))
                .build();

        tarjetaCredito = Tarjeta.builder()
                .idTarjeta(20L)
                .cuenta(cuenta)
                .numeroTarjeta("5412888899990000")
                .tipoTarjeta("Credito")
                .cupoAvance(new BigDecimal("3000.00"))
                .fechaVencimiento(LocalDate.of(2027, 8, 31))
                .build();
    }

    @Test
    @DisplayName("Listar tarjetas devuelve las tarjetas existentes")
    void testListarTarjetas() {
        when(tarjetaRepository.findAll()).thenReturn(Arrays.asList(tarjetaDebito, tarjetaCredito));

        List<TarjetaDTO> tarjetas = tarjetaService.listarTarjetas();

        assertNotNull(tarjetas);
        assertEquals(2, tarjetas.size());
    }

    @Test
    @DisplayName("Obtener tarjeta por ID existente")
    void testObtenerTarjetaPorId_Exitoso() {
        when(tarjetaRepository.findById(10L)).thenReturn(Optional.of(tarjetaDebito));

        TarjetaDTO dto = tarjetaService.obtenerTarjetaPorId(10L);

        assertNotNull(dto);
        assertEquals("4532111122223333", dto.getNumeroTarjeta());
        assertEquals("Debito", dto.getTipoTarjeta());
    }

    @Test
    @DisplayName("Obtener tarjeta por ID inexistente lanza ResourceNotFoundException")
    void testObtenerTarjetaPorId_NoEncontrada() {
        when(tarjetaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tarjetaService.obtenerTarjetaPorId(99L));
    }

    @Test
    @DisplayName("Crear tarjeta exitosamente")
    void testCrearTarjeta_Exitoso() {
        TarjetaDTO nueva = TarjetaDTO.builder()
                .idCuenta(1L)
                .numeroTarjeta("4532999988887777")
                .tipoTarjeta("Debito")
                .fechaVencimiento(LocalDate.of(2030, 1, 1))
                .build();

        when(tarjetaRepository.existsByNumeroTarjeta("4532999988887777")).thenReturn(false);
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuenta));
        when(tarjetaRepository.save(any(Tarjeta.class))).thenAnswer(inv -> {
            Tarjeta t = inv.getArgument(0);
            t.setIdTarjeta(30L);
            return t;
        });

        TarjetaDTO creada = tarjetaService.crearTarjeta(nueva);

        assertNotNull(creada);
        assertEquals(30L, creada.getIdTarjeta());
    }

    @Test
    @DisplayName("Validar tarjeta vencida lanza TarjetaVencidaException")
    void testValidarTarjetaVencida_Falla() {
        Tarjeta vencida = Tarjeta.builder()
                .idTarjeta(15L)
                .cuenta(cuenta)
                .numeroTarjeta("4532000000000000")
                .tipoTarjeta("Debito")
                .fechaVencimiento(LocalDate.now().minusDays(1))
                .build();

        assertThrows(TarjetaVencidaException.class, () -> tarjetaService.validarTarjetaParaOperar(vencida, 1L));
    }

    @Test
    @DisplayName("Validar tarjeta de débito asociada a otra cuenta lanza BusinessException")
    void testValidarTarjetaDebito_CuentaIncorrecta_Falla() {
        assertThrows(BusinessException.class, () -> tarjetaService.validarTarjetaParaOperar(tarjetaDebito, 2L));
    }
}
