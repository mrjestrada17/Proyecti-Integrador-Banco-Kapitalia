package com.banco.atm.service;

import com.banco.atm.dto.TipoOperacionDTO;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.TipoOperacionMapper;
import com.banco.atm.model.TipoOperacion;
import com.banco.atm.repository.TipoOperacionRepository;
import com.banco.atm.service.impl.TipoOperacionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TipoOperacionServiceTest {

    @Mock
    private TipoOperacionRepository tipoOperacionRepository;

    @Spy
    private TipoOperacionMapper tipoOperacionMapper;

    @InjectMocks
    private TipoOperacionServiceImpl tipoOperacionService;

    private TipoOperacion retiro;
    private TipoOperacion transferencia;

    @BeforeEach
    void setUp() {
        retiro = TipoOperacion.builder()
                .idTipoOperacion(1L)
                .nombreOperacion("Retiro")
                .requiereDestino(false)
                .build();

        transferencia = TipoOperacion.builder()
                .idTipoOperacion(3L)
                .nombreOperacion("Transf. Enviada")
                .requiereDestino(true)
                .build();
    }

    @Test
    @DisplayName("Listar tipos de operación retorna colección completa")
    void testListarTiposOperacion() {
        when(tipoOperacionRepository.findAll()).thenReturn(Arrays.asList(retiro, transferencia));

        List<TipoOperacionDTO> lista = tipoOperacionService.listarTiposOperacion();

        assertNotNull(lista);
        assertEquals(2, lista.size());
    }

    @Test
    @DisplayName("Obtener tipo de operación por nombre existente")
    void testObtenerPorNombre_Exitoso() {
        when(tipoOperacionRepository.findByNombreOperacionIgnoreCase("Retiro")).thenReturn(Optional.of(retiro));

        TipoOperacionDTO dto = tipoOperacionService.obtenerPorNombre("Retiro");

        assertNotNull(dto);
        assertEquals("Retiro", dto.getNombreOperacion());
        assertFalse(dto.getRequiereDestino());
    }

    @Test
    @DisplayName("Obtener tipo de operación inexistente lanza ResourceNotFoundException")
    void testObtenerPorNombre_NoEncontrado() {
        when(tipoOperacionRepository.findByNombreOperacionIgnoreCase("Inexistente")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tipoOperacionService.obtenerPorNombre("Inexistente"));
    }
}
