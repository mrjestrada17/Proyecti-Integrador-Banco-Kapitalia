package com.banco.atm.service;

import com.banco.atm.dto.CuentaDTO;
import com.banco.atm.exception.BusinessException;
import com.banco.atm.exception.ResourceNotFoundException;
import com.banco.atm.mapper.CuentaMapper;
import com.banco.atm.model.Cuenta;
import com.banco.atm.repository.CuentaRepository;
import com.banco.atm.service.impl.CuentaServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CuentaServiceTest {

    @Mock
    private CuentaRepository cuentaRepository;

    @Spy
    private CuentaMapper cuentaMapper;

    @InjectMocks
    private CuentaServiceImpl cuentaService;

    private Cuenta cuenta;

    @BeforeEach
    void setUp() {
        cuenta = Cuenta.builder()
                .idCuenta(1L)
                .numeroCuenta("1001001001001001")
                .tipoCuenta("Ahorros")
                .saldoDisponible(new BigDecimal("1500.00"))
                .estado("Activa")
                .build();
    }

    @Test
    @DisplayName("Listar cuentas retorna la lista mapeada a DTOs")
    void testListarCuentas() {
        when(cuentaRepository.findAll()).thenReturn(Arrays.asList(cuenta));

        List<CuentaDTO> resultado = cuentaService.listarCuentas();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("1001001001001001", resultado.get(0).getNumeroCuenta());
    }

    @Test
    @DisplayName("Obtener cuenta por ID existente retorna la cuenta")
    void testObtenerCuentaPorId_Exitoso() {
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuenta));

        CuentaDTO dto = cuentaService.obtenerCuentaPorId(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getIdCuenta());
        assertEquals("Ahorros", dto.getTipoCuenta());
    }

    @Test
    @DisplayName("Obtener cuenta por ID inexistente lanza ResourceNotFoundException")
    void testObtenerCuentaPorId_NoEncontrada() {
        when(cuentaRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> cuentaService.obtenerCuentaPorId(99L));
    }

    @Test
    @DisplayName("Crear cuenta exitosa cuando el número no existe previamente")
    void testCrearCuenta_Exitoso() {
        CuentaDTO nuevoDTO = CuentaDTO.builder()
                .numeroCuenta("5005005005005005")
                .tipoCuenta("Corriente")
                .saldoDisponible(new BigDecimal("2000.00"))
                .estado("Activa")
                .build();

        when(cuentaRepository.existsByNumeroCuenta("5005005005005005")).thenReturn(false);
        when(cuentaRepository.save(any(Cuenta.class))).thenAnswer(inv -> {
            Cuenta c = inv.getArgument(0);
            c.setIdCuenta(5L);
            return c;
        });

        CuentaDTO creada = cuentaService.crearCuenta(nuevoDTO);

        assertNotNull(creada);
        assertEquals(5L, creada.getIdCuenta());
        verify(cuentaRepository, times(1)).save(any(Cuenta.class));
    }

    @Test
    @DisplayName("Crear cuenta duplicada lanza BusinessException")
    void testCrearCuenta_Duplicada() {
        CuentaDTO duplicada = CuentaDTO.builder()
                .numeroCuenta("1001001001001001")
                .tipoCuenta("Ahorros")
                .build();

        when(cuentaRepository.existsByNumeroCuenta("1001001001001001")).thenReturn(true);

        assertThrows(BusinessException.class, () -> cuentaService.crearCuenta(duplicada));
    }

    @Test
    @DisplayName("Actualizar saldo con monto válido actualiza la entidad")
    void testActualizarSaldo_Exitoso() {
        when(cuentaRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(cuenta));
        when(cuentaRepository.save(any(Cuenta.class))).thenAnswer(inv -> inv.getArgument(0));

        CuentaDTO actualizada = cuentaService.actualizarSaldo(1L, new BigDecimal("3000.00"));

        assertNotNull(actualizada);
        assertEquals(new BigDecimal("3000.00"), actualizada.getSaldoDisponible());
    }

    @Test
    @DisplayName("Cambiar estado de cuenta a Bloqueada")
    void testCambiarEstado_Exitoso() {
        when(cuentaRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(cuenta));
        when(cuentaRepository.save(any(Cuenta.class))).thenAnswer(inv -> inv.getArgument(0));

        CuentaDTO actualizada = cuentaService.cambiarEstado(1L, "Bloqueada");

        assertNotNull(actualizada);
        assertEquals("Bloqueada", actualizada.getEstado());
    }
}
