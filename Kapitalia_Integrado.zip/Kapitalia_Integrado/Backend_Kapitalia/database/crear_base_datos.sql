-- Ejecutar desde phpMyAdmin o la consola de MySQL de XAMPP.
CREATE DATABASE IF NOT EXISTS kapitalia
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE kapitalia;
-- Las tablas se crean automáticamente al iniciar Spring Boot (JPA/Hibernate).
